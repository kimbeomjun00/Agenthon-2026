# Focused optimization round — 2026-10-13

Target: finish within two hours of the user's 17:12 KST clarification. Preserve every
previous submission/research artifact. All quantitative comparisons remain exploratory:
2020–2024 was already seen, macro is a single revised vintage, official M0 and real
House accuracy remain unavailable. No claimed pristine holdout or guaranteed uplift.

Freeze four integration designs BEFORE this round's development comparison:
calibration, stack50, stack70, stackcal. Components reuse the frozen VExpert experts.
New combination learns exact empirical-mixture CRPS quadratic weights, regularized
toward anchor; per-asset baseline floors 50%/70%. It uses whole terminal-rank-coupled
trajectories and a common stratified mixture selector. Calibration operates in native
log/logit/linear space, clips weak horizon-specific median bias, and shares one spread
factor across horizons. No offline fitted weights or per-asset benchmark winner table.

Price anchor is the preceding fast_price composition; this post-comparison architecture
choice carries forward its existing limitation. Other anchors retain the numerical
baseline. Mixed/unknown/stale input retains the joint baseline, not unsafe pooled fits.

Eight resolved nonoverlapping unit-history folds, 256 draws. Chronological nested
guard: fit the first four, evaluate each later fold using only earlier folds; refit after
acceptance. Gate marginal gain 1%, wins 60%, and past joint loss. Guard results are
unit-local selection evidence, not subsequent-period performance.

Development 2006–2019, 18 origins per daily panel and up to 18 macro origins, 512
paths. Choose one global integration design using development only; do not use a
2020–2024 per-asset winner table. Then freeze that source/design and compare original
VSpecial, previous fast_price and the chosen actual integration on all primary origins
with 2000 paths, seeds 42/77; evaluate horizon sensitivity, single targets, mixed input
and denser macro windows if time permits. Average seeds within origins, never count
overlapping windows as independent samples. Official score functions remain untouched.

Package sources, aggregate losses, reproducibility and QA; exclude raw panels, forecasts,
answers, per-case losses and team authentication. No Codabench submission or registry
push in this request. Governing official revision: T2 a2c93e7b66b8c6a6c429fda81d6bc7873b7c5dec,
common 2.6.0 bd01548e34d21fd660d88fd06157078fb25ece4e; artifact policy 2026-09-21.1.

Refinement before development: purge any origin whose longest realized horizon reaches
2020 from the 2006–2019 development split. Earlier-origin labels alone do not establish
split separation. Pilot outputs are diagnostic only and never select the final design.
Training QP minimizes the exact CRPS of the finite empirical-component mixture (biased
spread denominator); all guard/evaluation scoring uses the unchanged official fair
ensemble estimator. The two are not falsely labeled numerically identical at 256 draws.

Release amendment AFTER primary results (explicitly post-comparison): stack50 is retained
as an optimization research option but not promoted as a uniform improvement. Final
stable dispatcher preserves previous_fast exactly on pure known domains and safe baseline
on mixed/unknown inputs. RELEASE_DECISION.json discloses what was already seen. This
does not replace the frozen optimization design, erase failed comparisons, or establish
an untouched holdout. Control sample equality is tested on synthetic and real histories;
the final release image receives its own full tests, all 103 gates and offline smoke.
