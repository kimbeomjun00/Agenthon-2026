"""Exact mixture arithmetic, weights, chronological guards and cutoff invariance."""
import sys
sys.path.insert(0,'/expertlab')
import numpy as np
import pytest
from qfbench2_common.scoring.crps import crps_ensemble
from vnext import stacking as st
from test_experts import fixture

def test_release_dispatcher_uses_development_selected_design(monkeypatch):
    from vnext import optimized
    calls=[]
    monkeypatch.setattr(optimized,'_forecast',lambda *args,**kwargs:calls.append(kwargs['mode']))
    optimized.forecast({},[],None,'2020-01-01','level',128,42)
    assert calls==['stack50']

def test_cross_abs_matches_independent_quadratic_bruteforce():
    rng=np.random.default_rng(13);x=rng.normal(size=47);z=rng.normal(size=61)
    assert np.allclose(st.cross_abs(x,z),np.abs(x[:,None]-z[None,:]).mean(),rtol=1e-13)

def test_moments_match_official_biased_empirical_crps():
    rng=np.random.default_rng(55);s=rng.normal(size=(128,3,2));y=rng.normal(size=(3,2));scale=np.ones((3,2))
    A,B=st.moments({'anchor':s},y,scale,['anchor'])
    expected=crps_ensemble(s.reshape(128,-1),y.reshape(-1),fair=False).reshape(3,2).mean(axis=0)
    assert np.allclose(A[0]-.5*B[0,0],expected,rtol=1e-12)

def test_qp_simplex_floor_and_asset_menu():
    rng=np.random.default_rng(91);sims={'anchor':rng.normal(size=(128,3,2)),
       'rw_vol':rng.normal(.2,1,(128,3,2)),'har_proxy':rng.normal(.4,.5,(128,3,2))}
    y=np.ones((3,2))*.4;A,B=st.moments(sims,y,np.ones((3,2)),list(sims))
    w=st.fit_weights([{'A':A,'B':B}]*4,list(sims),['UST_2Y','BAB'],['UST_2Y','BAB'],st.CONFIGS['stack70'])
    assert np.allclose(w.sum(axis=0),1.) and np.all(w>=0) and np.all(w[0]>=.7-1e-8)
    assert w[2,0]==0

def test_trajectory_mix_anchor_identity_and_stratified_weights():
    rng=np.random.default_rng(47);base=rng.normal(size=(100,3,1));other=base+20
    weights=np.array([[1.],[0.]])
    assert np.array_equal(st.coupled_mix({'anchor':base,'rw_vol':other},['anchor','rw_vol'],weights,np.array([[5,21,63]]),42),base)
    weights=np.array([[.7],[.3]])
    sample=st.coupled_mix({'anchor':base,'rw_vol':other},['anchor','rw_vol'],weights,np.array([[5,21,63]]),42)
    assert np.sum(sample[:,0,0]>10)==30

@pytest.mark.parametrize('group',['rates','fx','factors','macro'])
def test_optimized_cutoff_invariance_finiteness_and_bounds(group):
    panels,assets,dates,monthly=fixture(group);asof=str(dates[-20].date())
    targets=assets[:2];steps=np.tile([1,3,9] if monthly else [5,21,63],(2,1))
    target='log_return' if group=='factors' else 'level'
    changed={'p':panels['p'].copy()};changed['p'].loc[changed['p']['date']>asof,'value']*=100
    a,ma=st.forecast(panels,targets,steps,asof,target,128,42,monthly,'stack70')
    b,mb=st.forecast(changed,targets,steps,asof,target,128,42,monthly,'stack70')
    assert np.array_equal(a,b) and ma==mb and np.isfinite(a).all()
    if group=='fx':assert (a>0).all()

def test_native_calibration_positive_prices_and_bounded_unemployment():
    sample=np.ones((128,3,2));sample[:,:,0]*=150;sample[:,:,1]*=5
    params=(np.ones((3,2))*-.35,np.ones(2)*1.5)
    out=st.apply_calibration(sample,['CPI_ALL','UNRATE'],params)
    assert (out[:,:,0]>0).all() and ((out[:,:,1]>0)&(out[:,:,1]<100)).all()

def test_mixed_input_preserves_joint_baseline():
    panels,assets,dates,monthly=fixture('rates');frame=panels['p'].copy()
    extra=frame[frame['asset']==assets[0]].copy();extra['asset']='EUR';extra['value']=np.exp(extra['value']/10)
    import pandas as pd
    mixed={'p':pd.concat([frame,extra])};targets=[assets[0],'EUR'];steps=np.tile([5,21,63],(2,1));asof=str(dates[-1].date())
    sample,meta=st.forecast(mixed,targets,steps,asof,'level',128,42)
    base,_=st.safe(mixed,targets,steps,asof,'level',128,42)
    assert np.array_equal(sample,base) and 'joint_baseline' in meta['engine']

def test_guard_fits_only_folds_resolved_before_its_cutoff(monkeypatch):
    import pandas as pd
    original=st.optimize_fold;checked=[]
    def wrapped(folds,names,assets,context,steps,config,seed,held):
        if 'input_end' in held:
            assert all(pd.Timestamp(f['resolved_end'])<=pd.Timestamp(held['input_end']) for f in folds)
            assert all(held is not f for f in folds)
            checked.append(held['input_end'])
        return original(folds,names,assets,context,steps,config,seed,held)
    monkeypatch.setattr(st,'optimize_fold',wrapped)
    panels,assets,dates,_=fixture('rates')
    st.forecast(panels,['UST_2Y'],np.array([[5,21,63]]),str(dates[-1].date()),'level',128,42,False,'stack50')
    assert len(checked)>=2
