# Reproduce research without replacing any submitted ZIP or registry image.
param(
 [Parameter(Mandatory=$true)][string]$RepositoryRoot,
 [ValidateSet('All','Validate','Development','Evaluation','Sensitivity','Single','Mixed','Dense')][string]$Phase='All',
 [ValidatePattern('^[A-Za-z0-9_-]+$')][string]$RunPrefix='repro'
)
$ErrorActionPreference='Stop'
$taskBundle=Split-Path -Parent $PSScriptRoot
$taskRepo=(Resolve-Path -LiteralPath $RepositoryRoot).Path
$taskLab=(Resolve-Path -LiteralPath $PSScriptRoot).Path
$taskBaseline=(Resolve-Path -LiteralPath (Join-Path $taskBundle 'VSpecial_baseline')).Path
$taskLegacy=(Resolve-Path -LiteralPath (Join-Path $taskLab 'legacy')).Path
$taskTests=(Resolve-Path -LiteralPath (Join-Path $taskBundle 'VStack/tests')).Path
if (!(Test-Path -LiteralPath (Join-Path $taskRepo 'V11/units'))) { throw 'RepositoryRoot must contain V11/units and the original panels' }
docker build --platform linux/amd64 -t agenthon-vstack-stable:research (Join-Path $taskBundle 'VStack')
if ($LASTEXITCODE -ne 0) { throw 'Research image build failed' }
$taskMounts=@('--rm','--network','none','--cpus','2','--memory','3g','-e','OPENBLAS_NUM_THREADS=1',
 '--mount',"type=bind,source=$taskRepo,target=/repo,readonly",
 '--mount',"type=bind,source=$taskLab,target=/lab",
 '--mount',"type=bind,source=$taskBaseline,target=/baseline,readonly",
 '--mount',"type=bind,source=$taskLegacy,target=/oldlab,readonly",
 '--mount',"type=bind,source=$taskTests,target=/tests,readonly")
if ($Phase -in @('All','Validate')) {
 docker run @taskMounts agenthon-vstack-stable:research python -m pytest /tests /lab/test_experts.py /lab/test_stacking.py /lab/test_stable.py `
  /lab/audit_tests/test_audit_cases.py /lab/audit_tests/test_refinements.py /lab/audit_tests/test_geometric.py -q -p no:cacheprovider
 if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed' }
 docker run @taskMounts agenthon-vstack-stable:research python /lab/validate.py --mode stable `
  --units /repo/V11/units --out "/lab/results/${RunPrefix}_gates" --draws 2000
 if ($LASTEXITCODE -ne 0) { throw 'Public output gates failed' }
}
foreach ($taskPhase in @('Development','Evaluation','Sensitivity','Single','Dense','Mixed')) {
 if ($Phase -ne 'All' -and $Phase -ne $taskPhase) { continue }
 $taskSeeds=@(42,77);$taskPanels=@('rates','fx','factors','macro')
 if ($taskPhase -eq 'Development') { $taskSeeds=@(42) }
 if ($taskPhase -eq 'Dense') { $taskPanels=@('macro') }
 if ($taskPhase -eq 'Mixed') { $taskPanels=@('mixed') }
 foreach ($taskPanel in $taskPanels) {
  foreach ($taskSeed in $taskSeeds) {
   $taskLabel="${RunPrefix}_${taskPhase}_${taskSeed}_${taskPanel}"
   if ($taskPhase -eq 'Mixed') {
    docker run @taskMounts agenthon-vstack-stable:research python /lab/mixed_experiment.py --mode stack50 `
     --draws 1000 --count 8 --seed $taskSeed --out "/lab/results/$taskLabel"
   } else {
    $taskSplit='evaluation';$taskDraws='2000';$taskCount='0';$taskModes='stack50';$taskExtra=@()
    if ($taskPhase -eq 'Development') { $taskSplit='development';$taskDraws='512';$taskCount='18';$taskModes='calibration,stack50,stack70,stackcal' }
    if ($taskPhase -eq 'Sensitivity') {
     $taskExtra=@('--horizons','5,21');$taskCount='18'
     if ($taskPanel -eq 'macro') { $taskExtra=@('--horizons','1,3,6');$taskCount='0' }
    }
    if ($taskPhase -eq 'Single') { $taskExtra=@('--single-all');$taskCount='4';$taskDraws='1000' }
    if ($taskPhase -eq 'Dense') { $taskExtra=@('--stride','1');$taskDraws='1000' }
    docker run @taskMounts agenthon-vstack-stable:research python /lab/experiment.py --panel $taskPanel `
     --split $taskSplit --draws $taskDraws --count $taskCount --modes $taskModes --seed $taskSeed `
     --out "/lab/results/$taskLabel" @taskExtra
   }
   if ($LASTEXITCODE -ne 0) { throw "Experiment failed: $taskLabel" }
  }
 }
}
# Analyze each phase separately with analyze.py (Python + numpy/pandas), using fresh paths.
# Seeds are averaged within origins. Dense windows overlap; do not treat them as independent.
# Source market panels and any actual submission/team-claim files are intentionally absent.
if ($Phase -eq 'All') {
 docker run @taskMounts agenthon-vstack-stable:research python /lab/finalize_analysis.py --run-prefix $RunPrefix
 if ($LASTEXITCODE -ne 0) { throw 'Independent aggregate verification failed' }
}
# A single completed phase can be checked with finalize_analysis.py --profile primary
# (or sensitivity/single/mixed/dense) --run-prefix <RunPrefix> inside the same mounts.
