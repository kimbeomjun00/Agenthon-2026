"""Select one global integration design on purged development evidence only."""
import csv,hashlib,json,math,pathlib
from statistics import fmean
ROOT=pathlib.Path(__file__).resolve().parent

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def main():
    result=[];hashes=[];panels={}
    for family in ['rates','fx','factors','macro']:
        folder=ROOT/'results'/f'dev_{family}'
        run=json.loads((folder/'run.json').read_text());assert run['target_window_year_end_purged']
        assert run['split']=='development';hashes.append(run['model_hashes']['stacking.py'])
        table=read(folder/'joint_summary.csv');panels[family]=table
        assert {r['model'] for r in table}=={'submitted','safe','previous_fast','calibration','stack50','stack70','stackcal'}
    assert len(set(hashes))==1
    for mode in ['calibration','stack50','stack70','stackcal']:
        relative=[];rows={}
        for family,table in panels.items():
            control=next(r for r in table if r['model']=='previous_fast');candidate=next(r for r in table if r['model']==mode)
            crps=float(candidate['crps_scaled'])/float(control['crps_scaled'])
            joint=float(candidate['local_composite'])/float(control['local_composite'])
            relative.append(.5*math.log(crps)+.5*math.log(joint))
            rows[family]={'crps_gain_vs_previous_fast':1-crps,'local_composite_gain_vs_previous_fast':1-joint}
        result.append({'mode':mode,'development_objective':fmean(relative),'panels':rows})
    selected=min(result,key=lambda r:r['development_objective'])
    frozen={'selected_mode':selected['mode'],'selection':'global design, equal panel weights, 50% log CRPS ratio + 50% log local-composite ratio, vs previous_fast',
            'selected_on':'2006–2019 origins AND all their target dates before 2020; 512 draws; no subsequent-period ranking used',
            'stacking_py_sha256':hashes[0],'design_comparisons':result,'evaluation_period_already_explored':True,
            'no_pristine_holdout_or_official_score':True}
    dest=ROOT/'DESIGN_FREEZE.json';assert not dest.exists(),'Never overwrite design freeze'
    dest.write_text(json.dumps(frozen,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(frozen,ensure_ascii=True,indent=2))

if __name__=='__main__':main()
