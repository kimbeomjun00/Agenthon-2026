"""## Executive summary (read this first)
Measure every available asset at artificial historical cutoffs, using canonical metrics.
Development uses 2006-2019; 2020-2024 is a subsequent evaluation already explored in VNext.
Only losses and provenance are saved. This does not score the authored practice cards.
"""
from __future__ import annotations
import argparse,hashlib,json,pathlib,time,warnings
import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from qfbench2_track_forecasting.scoring import _composite
from qfbench2_track_forecasting.cli import _draw
from v11_new.production_cli import _daily_e2_draws
from vnext.numeric import forecast as previous
from vnext.specialists import prepare,paths,forecast,DAILY,MONTHLY,_scale
from vnext.inflation import forecast as inflation_forecast,candidates as inflation_candidates
from vnext.crossasset import candidate as crossasset_candidate,KINDS as CROSS_KINDS

warnings.filterwarnings('ignore',category=UserWarning)
FILES={'rates':'rates_daily.parquet','fx':'g10_fx_daily.parquet',
       'factors':'factors_daily.parquet','macro':'macro_monthly.parquet'}

def sources(root):
    result={}
    for name,file in FILES.items():
        p=max((root/'units').glob('*/'+file),key=lambda p:p.stat().st_size)
        frame=pd.read_parquet(p);frame['date']=pd.to_datetime(frame['date'])
        result[name]=(p,frame,'asset' if 'asset' in frame else 'asset_id')
    return result

def composite(sample,truth):
    return _composite(sample.transpose(0,2,1).reshape(len(sample),-1),truth.T.reshape(-1),
           weights=(.5,.3,.2),tail_levels=(.01,.05,.95,.99),joint='variogram',tail_metric='pinball',ref_scale=None)

def expectation_scale(reference,seed):
    # A LOCAL baseline expectation, not an official organizer ref_scale.
    rng=np.random.default_rng(seed+601)
    outcomes=reference[rng.choice(len(reference),size=24,replace=False)]
    means={k:0. for k in ('marginal','joint','tail')}
    for truth in outcomes:
        values=composite(reference,truth)
        for k in means:means[k]+=values[k]/len(outcomes)
    return {k:max(v,1e-12) for k,v in means.items()}

def run(args):
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/opt/vnext').glob('*.py')}
    asset_rows=[];joint_rows=[];start=time.monotonic();origin_manifest=[]
    src=sources(pathlib.Path(args.root))
    panel,pathframe,acol=args.panel,*src[args.panel][1:]
    path=src[args.panel][0];df=pathframe
    assets=sorted(df[acol].unique().tolist())
    wide=df.pivot(index='date',columns=acol,values='value').reindex(columns=assets).dropna()
    monthly=panel=='macro';target='log_return' if panel=='factors' else 'level'
    hs=np.array(list(map(int,args.horizons.split(',')))) if args.horizons else np.array([1,3,9] if monthly else [5,21,63])
    maxh=int(hs.max())
    minimum=84 if monthly else 750
    lo,hi=(2006,2019) if args.split=='development' else (2020,2024)
    eligible=np.flatnonzero((wide.index.year>=lo)&(wide.index.year<=hi)&(np.arange(len(wide))>=minimum)&(np.arange(len(wide))+maxh<len(wide)))
    # Strict non-overlap of outcome windows; calendar-year dependence remains.
    indices=[]
    for ix in eligible:
        if not indices or ix-indices[-1]>=maxh:indices.append(int(ix))
    if args.count and len(indices)>args.count:
        indices=[indices[i] for i in np.unique(np.linspace(0,len(indices)-1,args.count).round().astype(int))]
    kinds=(MONTHLY if monthly else DAILY) if args.candidates else []
    for case,ix in enumerate(indices):
        cutoff=wide.index[ix];asof=str(cutoff.date());panels={panel:df[df['date']<=cutoff].copy()}
        future=wide.iloc[ix+1:ix+1+maxh].to_numpy(float)
        truth=np.stack([np.log1p(future[:h]).sum(axis=0) if target=='log_return' else future[h-1] for h in hs])
        steps=np.tile(hs,(len(assets),1));state=prepare(panels,assets,asof,target,monthly)
        scale=np.maximum(_scale(state.x)*np.sqrt(hs[:,None]),1e-8)
        sims=paths(state,steps,args.draws,args.seed,kinds) if kinds else {}
        if args.inflation_grid:sims.update(inflation_candidates(state,steps,args.draws,args.seed))
        if args.crossasset_grid:
            sims.update({k:crossasset_candidate(state,steps,args.draws,args.seed,k) for k in CROSS_KINDS
                         if k!='pca_revert' or target=='level'})
        if monthly:
            raw,_=_draw(panels,assets,hs.tolist(),asof,args.draws,args.seed,target_type=target,panel_steps=steps)
            sims['v11']=raw.transpose(0,2,1)
        else:sims['v11'],*_=_daily_e2_draws(panels,assets,hs.tolist(),asof,target,args.draws,args.seed)
        reference,_=_draw(panels,assets,hs.tolist(),asof,args.draws,args.seed+191,target_type=target,panel_steps=steps if monthly else None)
        ref=reference.transpose(0,2,1)
        refscale=expectation_scale(ref,args.seed)
        asset_scales=[expectation_scale(ref[:,:,ai:ai+1],args.seed) for ai in range(len(assets))]
        if args.router:
            sims['specialists'],meta=forecast(panels,assets,steps,asof,target,args.draws,args.seed,monthly)
            origin_manifest.append({'asof':asof,'selection':meta})
            sims['conservative'],meta=forecast(panels,assets,steps,asof,target,args.draws,args.seed,monthly,policy='conservative')
            origin_manifest.append({'asof':asof,'conservative_selection':meta})
        if args.previous:sims['vnext'],_=previous(panels,assets,steps,asof,target,args.draws,args.seed,monthly=monthly)
        if args.inflation:
            sims['inflation'],meta=inflation_forecast(panels,assets,steps,asof,target,args.draws,args.seed,monthly)
            origin_manifest.append({'asof':asof,'inflation_selection':meta})
        for model,sample in sims.items():
            score=composite(sample,truth)
            normalized=sum(w*score[k]/refscale[k] for w,k in zip((.5,.3,.2),('marginal','joint','tail')))
            low,high=np.quantile(sample,[.05,.95],axis=0)
            crps=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
            joint_rows.append({'case':case,'panel':panel,'asof':asof,'model':model,'seed':args.seed,
                'draws':args.draws,'local_composite':normalized,'crps_scaled':float(np.mean(crps/scale)),
                'coverage90':float(np.mean((truth>=low)&(truth<=high))),**{k:score[k] for k in ('marginal','joint','tail')},
                **{'local_scale_'+k:v for k,v in refscale.items()}})
            for ai,a in enumerate(assets):
                per=composite(sample[:,:,ai:ai+1],truth[:,ai:ai+1])
                asset_rows.append({'case':case,'panel':panel,'asset':a,'asof':asof,'model':model,'seed':args.seed,
                    'crps_scaled':float(np.mean(crps[:,ai]/scale[:,ai])),
                    'local_composite':sum(w*per[k]/asset_scales[ai][k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                    'coverage90':float(np.mean((truth[:,ai]>=low[:,ai])&(truth[:,ai]<=high[:,ai]))),
                    **{k:per[k] for k in ('marginal','joint','tail')}})
        pd.DataFrame(asset_rows).to_csv(out/'asset_metrics.csv',index=False)
        pd.DataFrame(joint_rows).to_csv(out/'joint_metrics.csv',index=False)
        print(panel,args.split,case+1,len(indices),asof,f'{time.monotonic()-start:.1f}s',flush=True)
    a=pd.DataFrame(asset_rows);j=pd.DataFrame(joint_rows)
    a.groupby(['panel','asset','model']).mean(numeric_only=True).reset_index().to_csv(out/'asset_summary.csv',index=False)
    j.groupby(['panel','model']).mean(numeric_only=True).reset_index().to_csv(out/'joint_summary.csv',index=False)
    (out/'run.json').write_text(json.dumps(vars(args)|{'assets':assets,'cases':len(indices),
        'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source':str(path),
        'model_hashes':hashes,
        'seconds':time.monotonic()-start,'local_refscale':'24 MC truths from own reference; NOT official scales',
        'caveat':'2020-2024 already explored by previous VNext; macro single revised vintage'},indent=2))
    (out/'selections.json').write_text(json.dumps(origin_manifest,indent=2))
    print(j.groupby('model')[['crps_scaled','local_composite']].mean().to_string(),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='/repo/V11')
    ap.add_argument('--panel',choices=list(FILES),required=True);ap.add_argument('--split',choices=['development','evaluation'],default='development')
    ap.add_argument('--out',required=True);ap.add_argument('--draws',type=int,default=1000)
    ap.add_argument('--seed',type=int,default=42);ap.add_argument('--count',type=int,default=0)
    ap.add_argument('--horizons',default='')
    ap.add_argument('--candidates',action='store_true');ap.add_argument('--router',action='store_true');ap.add_argument('--previous',action='store_true')
    ap.add_argument('--inflation',action='store_true');ap.add_argument('--inflation-grid',action='store_true')
    ap.add_argument('--crossasset-grid',action='store_true')
    run(ap.parse_args())
