"""Prove the release composition preserves each measured control sample exactly."""
import numpy as np
import pandas as pd
import pytest
from test_experts import fixture
from vnext import stable


@pytest.mark.parametrize('group',['rates','fx','factors','macro'])
def test_pure_domain_is_bit_exact_preceding_candidate(group):
    panels,assets,dates,monthly=fixture(group)
    steps=np.tile([1,3,9] if monthly else [5,21,63],(len(assets),1))
    target='log_return' if group=='factors' else 'level'
    asof=str(dates[-1].date())
    actual,meta=stable.forecast(panels,assets,steps,asof,target,128,42,monthly)
    expected,_=stable.previous_forecast(panels,assets,steps,asof,target,128,42,monthly)
    assert np.array_equal(actual,expected) and 'exactly previous_fast' in meta['release_policy']


def test_mixed_domain_is_bit_exact_joint_baseline():
    panels,assets,dates,_=fixture('rates');frame=panels['p'].copy()
    extra=frame[frame['asset']==assets[0]].copy();extra['asset']='EUR';extra['value']=np.exp(extra['value']/10)
    panels={'p':pd.concat([frame,extra],ignore_index=True)}
    targets=['UST_2Y','EUR'];steps=np.tile([5,21,63],(2,1));asof=str(dates[-1].date())
    actual,_=stable.forecast(panels,targets,steps,asof,'level',128,42)
    expected,_=stable.safe_forecast(panels,targets,steps,asof,'level',128,42)
    assert np.array_equal(actual,expected)
