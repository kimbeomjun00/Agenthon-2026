"""Check completeness and independently recompute paired, seed-averaged comparisons."""
import argparse,hashlib,json,pathlib
from types import SimpleNamespace
import numpy as np
import pandas as pd
import analyze

LAB=pathlib.Path(__file__).resolve().parent
ROOT=LAB/'results'
PANELS=['rates','fx','factors','macro']
PREFIX=''
PROFILES={
 'primary':[f'eval{s}_{p}' for s in [42,77] for p in PANELS],
 'sensitivity':[f'sens{s}_{p}' for s in [42,77] for p in PANELS],
 'single':[f'single{s}_{p}' for s in [42,77] for p in PANELS],
 'mixed':[f'mixed{s}' for s in [42,77]],
 'dense':[f'dense{s}_macro' for s in [42,77]],
}

def checked_profile(profile):
    runs=PROFILES[profile];records=[]
    frozen=json.loads((LAB/'DESIGN_FREEZE.json').read_text(encoding='utf8'))
    for name in runs:
        record=json.loads((ROOT/name/'run.json').read_text())
        assert record['model_hashes']['stacking.py']==frozen['stacking_py_sha256'],name
        if profile!='mixed':assert record['target_window_year_end_purged']
        records.append(record)
    output=ROOT/f'{PREFIX}{profile}_analysis'
    if not output.exists():analyze.main(SimpleNamespace(root=str(ROOT),patterns=','.join(runs),out=str(output)))
    all_checks={}
    for scope,file,keys,aggfile in [
       ('asset','asset_metrics.csv',['panel','asset','asof','model'],'asset_summary.csv'),
       ('panel','joint_metrics.csv',['panel','target_set','asof','model'],'panel_summary.csv')]:
        raw=pd.concat([pd.read_csv(ROOT/r/file) for r in runs],ignore_index=True)
        assert not raw.duplicated(keys+['seed']).any()
        assert (raw.groupby(keys)['seed'].nunique()==2).all(),'Unbalanced seeds'
        numeric=['crps_scaled','local_composite','marginal','joint','tail','coverage90']
        assert np.isfinite(raw[numeric].to_numpy()).all()
        paired=raw.groupby(keys)[numeric].mean().reset_index()
        calculated=paired.groupby([k for k in keys if k!='asof'])[numeric].mean().sort_index()
        saved=pd.read_csv(output/aggfile).set_index([k for k in keys if k!='asof']).sort_index()
        assert calculated.index.equals(saved.index)
        assert np.allclose(calculated[numeric],saved[numeric],rtol=1e-11,atol=1e-11)
        assert set(raw['model'])=={'submitted','safe','previous_fast','stack50'}
        all_checks[scope]={'raw_rows':len(raw),'paired_rows':len(paired),'aggregate_rows':len(saved),
                          'seeds_averaged_not_counted_as_cases':True}
    meta=json.loads((output/'analysis.json').read_text())
    return {'runs':runs,'checks':all_checks,'cases_per_panel':meta['cases_per_panel'],
            'draws':sorted(set(r['draws'] for r in records)),
            'overlapping_windows':meta['overlapping_windows']}

def comparison(table,profile,scope,candidate_model='stack50'):
    idcols=['panel','asset'] if scope=='asset' else ['panel','target_set']
    metrics=['crps_scaled','local_composite','marginal','joint','tail','coverage90']
    rows=[]
    for key,group in table.groupby(idcols):
        indexed=group.set_index('model');candidate=indexed.loc[candidate_model]
        row={'profile':profile,'measured_function':candidate_model,**dict(zip(idcols,key))}
        for metric in metrics:row[metric]=candidate[metric]
        for label,model in [('submitted','submitted'),('previous','previous_fast')]:
            for metric in metrics[:-1]:
                row[f'{metric}_gain_vs_{label}']=1-candidate[metric]/indexed.loc[model,metric]
        rows.append(row)
    return pd.DataFrame(rows)

def main():
    global PREFIX
    p=argparse.ArgumentParser();p.add_argument('--profile',choices=list(PROFILES)+['all'],default='all')
    p.add_argument('--run-prefix',default='');args=p.parse_args()
    if args.run_prefix:
        assert all(c.isalnum() or c in '_-' for c in args.run_prefix)
        PREFIX=args.run_prefix+'_'
        phase={'primary':'Evaluation','sensitivity':'Sensitivity','single':'Single','mixed':'Mixed','dense':'Dense'}
        for profile in PROFILES:
            groups=['mixed'] if profile=='mixed' else ['macro'] if profile=='dense' else PANELS
            PROFILES[profile]=[f'{PREFIX}{phase[profile]}_{seed}_{group}' for seed in [42,77] for group in groups]
    names=list(PROFILES) if args.profile=='all' else [args.profile]
    verified={name:checked_profile(name) for name in names}
    print(json.dumps(verified,indent=2))
    if args.profile!='all':return
    dest=LAB/f'{PREFIX}delivery_ready';dest.mkdir(exist_ok=True)
    assets=[];panels=[];stable_assets=[];stable_panels=[]
    for profile in names:
        folder=ROOT/f'{PREFIX}{profile}_analysis'
        assets.append(comparison(pd.read_csv(folder/'asset_summary.csv'),profile,'asset'))
        panels.append(comparison(pd.read_csv(folder/'panel_summary.csv'),profile,'panel'))
        control='safe' if profile=='mixed' else 'previous_fast'
        stable_assets.append(comparison(pd.read_csv(folder/'asset_summary.csv'),profile,'asset',control))
        stable_panels.append(comparison(pd.read_csv(folder/'panel_summary.csv'),profile,'panel',control))
    all_assets=pd.concat(assets,ignore_index=True);all_panels=pd.concat(panels,ignore_index=True)
    all_assets.to_csv(dest/'ASSET_ALL_PROFILES.csv',index=False,encoding='utf-8-sig')
    all_panels.to_csv(dest/'PANEL_COMPARISONS.csv',index=False,encoding='utf-8-sig')
    primary=all_assets[all_assets['profile']=='primary'].copy();assert len(primary)==28
    primary.to_csv(dest/'OPTIMIZED_ASSET_RESULTS_28.csv',index=False,encoding='utf-8-sig')
    stable_assets=pd.concat(stable_assets,ignore_index=True);stable_panels=pd.concat(stable_panels,ignore_index=True)
    stable_assets.to_csv(dest/'STABLE_ASSET_ALL_PROFILES.csv',index=False,encoding='utf-8-sig')
    stable_panels.to_csv(dest/'STABLE_PANEL_COMPARISONS.csv',index=False,encoding='utf-8-sig')
    stable_assets[stable_assets['profile']=='primary'].to_csv(dest/'ASSET_RESULTS_28.csv',index=False,encoding='utf-8-sig')
    (dest/'ANALYSIS_VERIFICATION.json').write_text(json.dumps({'profiles':verified,'assets':28,
      'frozen_stack_hash':json.loads((LAB/'DESIGN_FREEZE.json').read_text(encoding='utf8'))['stacking_py_sha256'],
      'official_score':False,'fresh_holdout':False},indent=2),encoding='utf8')
    print(all_panels[['profile','panel','crps_scaled_gain_vs_submitted','crps_scaled_gain_vs_previous',
                      'local_composite_gain_vs_submitted','local_composite_gain_vs_previous']].to_string(index=False))

if __name__=='__main__':main()
