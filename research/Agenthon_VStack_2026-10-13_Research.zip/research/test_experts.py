"""## Executive summary (read this first)
Test domain menus, transformations, cutoff invariance, covariates and joint integration.
"""
import numpy as np
import pandas as pd
import pytest
from vnext.experts import (candidates,context_state,native,decode,expand_steps,forecast,
                           menu,rank_align_baseline,choose_weights,resolved_truth,FX,FACTORS,RATES,MACRO)


def fixture(group):
    assets=sorted({'rates':set(RATES),'fx':FX,'factors':FACTORS,'macro':MACRO}[group])
    monthly=group=='macro';dates=pd.date_range('2000-01-01',periods=220,freq='MS') if monthly else pd.bdate_range('2000-01-03',periods=1250)
    rng=np.random.default_rng(981);shocks=rng.normal(0,1,(len(dates),len(assets)))
    common=rng.normal(0,1,(len(dates),1));shocks=.7*common+.7*shocks
    values=np.empty_like(shocks)
    for i,a in enumerate(assets):
        if group=='rates':values[:,i]=3+i*.1+np.cumsum(shocks[:,i]*.01)
        elif group=='fx':values[:,i]=np.exp(np.cumsum(shocks[:,i]*.005)+i*.05)
        elif group=='factors':values[:,i]=shocks[:,i]*.008+(.0002 if a=='MKT' else .00005)
        elif a in {'CPI_ALL','CPI_CORE','PCE_ALL','PCE_CORE'}:values[:,i]=100*np.exp(np.cumsum(.002+shocks[:,i]*.0005))
        elif a=='NFP':values[:,i]=100000+np.cumsum(100+shocks[:,i]*50)
        else:values[:,i]=5+.4*np.sin(np.arange(len(dates))/12)+shocks[:,i]*.05
    frame=pd.DataFrame({'date':np.repeat(dates,len(assets)),'asset':np.tile(assets,len(dates)),
                        'value':values.reshape(-1),'panel_id':group})
    return {'p':frame},assets,dates,monthly


@pytest.mark.parametrize('group',['rates','fx','factors','macro'])
def test_every_applicable_domain_candidate_is_finite(group):
    panels,assets,dates,monthly=fixture(group);target='log_return' if group=='factors' else 'level'
    s=context_state(panels,assets,str(dates[-1].date()),target,monthly)
    hs=[1,3,9] if monthly else [5,21,63];steps=np.tile(hs,(len(assets),1))
    sims=candidates(s,steps,256,42)
    for ai,a in enumerate(assets):
        assert len(menu(a,s.assets))>=4
        for k in menu(a,s.assets):
            assert k in sims and sims[k].shape==(256,3,len(assets))
            assert np.isfinite(sims[k]).all()
            if a in FX|{'CPI_ALL','CPI_CORE','PCE_ALL','PCE_CORE'}:assert (sims[k][:,:,ai]>0).all()
            if a=='UNRATE':assert ((sims[k][:,:,ai]>0)&(sims[k][:,:,ai]<100)).all()


def test_true_native_changes_recover_observed_levels():
    panels,assets,dates,_=fixture('macro');s=context_state(panels,assets,str(dates[-1].date()),'level',True)
    x,anchor,kinds=native(s)
    zero=np.zeros((2,9,len(assets)));steps=np.tile([1,3,9],(len(assets),1))
    result=decode(s,zero,steps,anchor,kinds)
    assert np.allclose(result,s.anchor,rtol=1e-12,atol=1e-9)


def test_one_target_can_use_supplied_curve_covariates():
    panels,assets,dates,_=fixture('rates');s=context_state(panels,['UST_2Y'],str(dates[-1].date()),'level',False)
    assert len(s.assets)==6 and s.assets[0]=='UST_2Y'
    assert 'curve_ns' in menu('UST_2Y',s.assets)
    matrix=expand_steps(s,['UST_2Y'],np.array([[5,21,63]]))
    assert matrix.shape==(6,3)


def test_whole_trajectory_rank_alignment_preserves_all_marginals():
    rng=np.random.default_rng(43);base=rng.normal(size=(128,3,2));ref=rng.normal(size=base.shape)
    aligned=rank_align_baseline(base,ref,np.tile([5,21,63],(2,1)))
    assert np.array_equal(np.sort(base,axis=0),np.sort(aligned,axis=0))
    for i in range(2):
        before={tuple(row) for row in base[:,:,i]};after={tuple(row) for row in aligned[:,:,i]}
        assert before==after


def test_router_uses_no_post_cutoff_values_or_new_covariate_names():
    panels,assets,dates,monthly=fixture('rates');asof=str(dates[1099].date())
    cut={'p':panels['p'][panels['p']['date']<=asof].copy()}
    changed={'p':panels['p'].copy()};changed['p'].loc[changed['p']['date']>asof,'value']*=20
    extra=changed['p'][(changed['p']['asset']=='UST_10Y')&(changed['p']['date']>asof)].copy();extra['asset']='UST_99Y'
    changed['p']=pd.concat([changed['p'],extra],ignore_index=True)
    a,ma=forecast(cut,['UST_2Y'],np.array([[5,21,63]]),asof,'level',256,42)
    b,mb=forecast(changed,['UST_2Y'],np.array([[5,21,63]]),asof,'level',256,42)
    assert np.array_equal(a,b) and ma==mb


def test_distinct_assets_receive_distinct_experts_when_past_evidence_supports_them():
    names=['baseline','rw_vol','har_proxy','ridge_condition']
    losses=np.ones((6,4,2));losses[:,2,0]=.6;losses[:,3,1]=.5
    w=choose_weights(losses,names,['BAB','HML'],['BAB','HML','MKT'])
    assert w[2,0]>.5 and w[3,1]>.5
    assert np.allclose(w.sum(axis=0),1.) and (w[0]>=.35).all()


def test_monthly_conditional_regression_retains_fitted_growth_intercept():
    dates=pd.date_range('2000-01-01',periods=220,freq='MS')
    frame=pd.DataFrame({'date':dates,'asset':'CPI_ALL','value':100*np.exp(.002*np.arange(220))})
    s=context_state({'p':frame},['CPI_ALL'],str(dates[-1].date()),'level',True)
    result=candidates(s,np.array([[1,3,9]]),256,42)['ridge_condition']
    assert np.median(result[:,2,0])>s.anchor[0]*1.016


def test_peg_expert_handles_inverse_quote_directions():
    dates=pd.bdate_range('2000-01-03',periods=1250);rng=np.random.default_rng(91)
    euro=np.exp(np.cumsum(rng.normal(0,.005,len(dates))))
    dkk=7.46/euro*np.exp(rng.normal(0,.00005,len(dates)))
    frame=pd.DataFrame({'date':np.repeat(dates,2),'asset':np.tile(['DKK','EUR'],len(dates)),
                        'value':np.stack([dkk,euro],axis=1).reshape(-1)})
    s=context_state({'p':frame},['DKK','EUR'],str(dates[-1].date()),'level',False)
    result=candidates(s,np.tile([5,21,63],(2,1)),512,42)['fx_peg']
    product=result[:,:,0]*result[:,:,1]
    assert (np.std(product,axis=0)/np.mean(product,axis=0)<.002).all()


def test_covariate_missing_dates_do_not_change_target_only_future_grain():
    panels,assets,dates,_=fixture('factors')
    panels['p']=panels['p'][~((panels['p']['asset']=='MKT')&panels['p']['date'].isin(dates[201:205]))]
    s=context_state(panels,['BAB'],str(dates[-1].date()),'log_return',False)
    end=int(np.flatnonzero(s.dates==dates[199])[0])+1
    truth=resolved_truth(s,['BAB'],np.array([[5,21,63]]),end)
    future=panels['p'][(panels['p']['asset']=='BAB')&(panels['p']['date']>dates[199])]['value'].to_numpy()
    expected=np.array([np.log1p(future[:h]).sum() for h in [5,21,63]])
    assert np.allclose(truth[:,0],expected)


def test_pure_domain_dispatch_matches_frozen_expert_core():
    from vnext.portfolio import forecast as portfolio
    panels,assets,dates,_=fixture('rates');asof=str(dates[-1].date());steps=np.tile([5,21,63],(len(assets),1))
    a,ma=forecast(panels,assets,steps,asof,'level',256,42)
    b,mb=portfolio(panels,assets,steps,asof,'level',256,42)
    assert np.array_equal(a,b) and ma==mb


def test_mixed_domain_dispatch_preserves_shape_and_cutoff():
    from vnext.portfolio import forecast as portfolio
    rates,_,dates,_=fixture('rates');fx,_,_,_=fixture('fx');panels={'r':rates['p'],'f':fx['p']}
    assets=['UST_2Y','UST_10Y','EUR','JPY'];steps=np.tile([5,21,63],(4,1));asof=str(dates[1099].date())
    past={k:frame[frame['date']<=asof] for k,frame in panels.items()}
    a,ma=portfolio(panels,assets,steps,asof,'level',256,42)
    b,mb=portfolio(past,assets,steps,asof,'level',256,42)
    assert np.array_equal(a,b) and ma==mb
    assert a.shape==(256,3,4) and (a[:,:,2:]>0).all()


@pytest.mark.parametrize('group',['rates','fx','factors','macro'])
def test_research_cache_is_numerically_equivalent_under_context_permutations(group):
    from cache_utils import CandidateCache
    panels,assets,dates,monthly=fixture(group);target='log_return' if group=='factors' else 'level'
    s=context_state(panels,[assets[-1]],str(dates[-1].date()),target,monthly)
    steps=np.tile([1,3,9] if monthly else [5,21,63],(len(s.assets),1))
    uncached=candidates(s,steps,256,42);cache=CandidateCache(candidates)
    first=cache(s,steps,256,42);second=cache(s,steps,256,42)
    assert list(first)==list(uncached) and cache.hits==1
    for name in uncached:
        assert np.allclose(first[name],uncached[name],rtol=1e-10,atol=1e-9),name
        assert np.array_equal(first[name],second[name])


def test_fast_price_composition_leaves_nonprice_macro_paths_exactly_unchanged():
    from vnext.fast_price import forecast as hybrid
    from vnext.inflation import forecast as baseline
    panels,assets,dates,_=fixture('macro');steps=np.tile([1,3,9],(len(assets),1));asof=str(dates[-1].date())
    a,meta=hybrid(panels,assets,steps,asof,'level',512,42,True)
    b,_=baseline(panels,assets,steps,asof,'level',512,42,True)
    for i,asset in enumerate(assets):
        if asset in {'NFP','UNRATE'}:assert np.array_equal(a[:,:,i],b[:,:,i])
    assert 'reused-period' in meta['selection_scope'] and np.isfinite(a).all()


def test_fast_price_composition_uses_only_cutoff_history():
    from vnext.fast_price import forecast as hybrid
    panels,assets,dates,_=fixture('macro');asof=str(dates[199].date());steps=np.tile([1,3,9],(len(assets),1))
    cut={'p':panels['p'][panels['p']['date']<=asof].copy()}
    a,ma=hybrid(panels,assets,steps,asof,'level',512,42,True)
    b,mb=hybrid(cut,assets,steps,asof,'level',512,42,True)
    assert np.array_equal(a,b) and ma==mb
