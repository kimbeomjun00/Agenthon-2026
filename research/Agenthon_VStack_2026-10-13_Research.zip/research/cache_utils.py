"""## Executive summary (read this first)
Reuse equivalent same-cutoff expert simulations across single-target research profiles.
Memory only, cleared each origin. No future outcomes, inference cache or fitted artifact.
"""
from dataclasses import replace
import hashlib
import numpy as np
from vnext.experts import menu


class CandidateCache:
    def __init__(self,generator):
        self.generator=generator;self.items={};self.hits=0;self.misses=0

    def clear(self):self.items.clear()

    def __call__(self,s,steps,draws,seed):
        order=np.argsort(s.assets);names=[s.assets[i] for i in order]
        canonical=replace(s,assets=names,levels=s.levels[names],x=s.x[:,order],
                          anchor=s.anchor[order],offsets=s.offsets[order])
        h=hashlib.sha256()
        for arr in [canonical.x,canonical.anchor,canonical.offsets,canonical.levels.to_numpy(),
                    canonical.levels.index.asi8,canonical.dates.asi8,steps[order]]:
            h.update(np.ascontiguousarray(arr).tobytes())
        key=(tuple(names),s.target,s.monthly,h.hexdigest(),draws,seed)
        if key not in self.items:
            self.items[key]=self.generator(canonical,steps[order],draws,seed);self.misses+=1
        else:self.hits+=1
        inverse=[names.index(a) for a in s.assets]
        models=list(dict.fromkeys(k for a in s.assets for k in menu(a,s.assets)))
        # Keep the original menu/draw ordering used by the frozen router.
        return {k:self.items[key][k][:,:,inverse].copy() for k in models}
