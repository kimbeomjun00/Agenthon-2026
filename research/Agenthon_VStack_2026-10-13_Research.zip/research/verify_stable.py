"""Check release/control draw equality on real first/last primary origins, both seeds."""
import argparse,hashlib,importlib.util,json,pathlib,time
import numpy as np
import pandas as pd
from vnext import stable

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--panel',choices=['rates','fx','factors','macro','mixed'],required=True)
    ap.add_argument('--out',required=True);args=ap.parse_args()
    spec=importlib.util.spec_from_file_location('legacy','/oldlab/experiment.py')
    legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
    sources=legacy.sources(pathlib.Path('/repo/V11'));group=args.panel
    folder=pathlib.Path('/lab/results')/('mixed42' if group=='mixed' else f'eval42_{group}')
    runs=json.loads((folder/'run.json').read_text());assets=runs['assets'];manifest={};panels={}
    for key in (['rates','fx'] if group=='mixed' else [group]):
        path,df,column=sources[key];panels[key]=df.rename(columns={column:'asset'})
        manifest[key]=hashlib.sha256(path.read_bytes()).hexdigest()
    if (folder/'joint_metrics.csv').is_file():
        cutoffs=sorted(pd.read_csv(folder/'joint_metrics.csv')['asof'].unique())
    else:
        # Published bundles intentionally omit per-origin losses. Retain only the
        # public cutoff dates from the original equality-check record for reruns.
        reference=json.loads((folder.parent/'release_equivalence'/f'{group}.json').read_text())
        cutoffs=sorted({row['asof'] for row in reference['checks']})
    monthly=group=='macro';target='log_return' if group=='factors' else 'level'
    steps=np.tile([1,3,9] if monthly else [5,21,63],(len(assets),1));rows=[]
    for asof in [cutoffs[0],cutoffs[-1]]:
        past={key:df[df['date']<=pd.Timestamp(asof)].copy() for key,df in panels.items()}
        for seed in [42,77]:
            t=time.monotonic();actual,_=stable.forecast(past,assets,steps,asof,target,2000,seed,monthly)
            control=stable.safe_forecast if group=='mixed' else stable.previous_forecast
            expected,_=control(past,assets,steps,asof,target,2000,seed,monthly)
            assert np.array_equal(actual,expected) and np.isfinite(actual).all()
            rows.append({'asof':str(asof),'seed':seed,'draws':2000,'exact_equality':True,
                         'sample_sha256':hashlib.sha256(actual.tobytes()).hexdigest(),
                         'seconds':time.monotonic()-t})
            print(group,asof,seed,'exact',flush=True)
    out=pathlib.Path(args.out);assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps({'panel':group,'assets':assets,'source_sha256':manifest,'checks':rows,
      'meaning':'direct release/control draw equivalence, not independent future accuracy'},indent=2))

if __name__=='__main__':main()
