"""## Executive summary (read this first)
Check cutoff invariance, unchanged non-price targets and positivity under extreme text shifts.
"""
import numpy as np
import pandas as pd
from vnext.refinements import forecast
from vnext.inflation import forecast as fixed
from vnext.cli import transform

def fixture():
    dates=pd.date_range('2000-01-01',periods=240,freq='MS');rng=np.random.default_rng(88)
    values=100+np.cumsum(rng.normal([.25,1.],[.05,.2],(240,2)),axis=0)
    frame=pd.DataFrame({'date':np.repeat(dates,2),'asset':np.tile(['CPI_ALL','NFP'],240),'value':values.reshape(-1)})
    return {'p':frame},dates

def test_soft_and_calibrated_use_only_cutoff_history():
    panels,dates=fixture();asof=str(dates[219].date());steps=np.tile([1,3,9],(2,1))
    cut={'p':panels['p'][panels['p']['date']<=asof]}
    for mode in ('soft','calibrated'):
        a,ma=forecast(panels,['CPI_ALL','NFP'],steps,asof,'level',512,42,True,mode)
        b,mb=forecast(cut,['CPI_ALL','NFP'],steps,asof,'level',512,42,True,mode)
        assert np.array_equal(a,b)
        assert ma==mb
        control,_=fixed(cut,['CPI_ALL','NFP'],steps,asof,'level',512,42,True)
        assert np.allclose(a[:,:,1],control[:,:,1],rtol=1e-12,atol=1e-12)

def test_extreme_negative_house_shift_preserves_positive_fx():
    base=np.exp(np.random.default_rng(1).normal(-2,.5,(1024,2,1)))
    scenario=[{'name':'stress','prob':1.,'assets':{'EUR':{'shift_sd':-2.5,'vol_scale':2.5}}}]
    result,_=transform(base,['EUR'],np.array([[5,63]]),scenario,42,positive_assets=['EUR'])
    assert np.isfinite(result).all() and (result>0).all()

def test_neutral_house_reply_is_exact_identity():
    base=np.random.default_rng(2).normal(size=(512,3,1))
    scenario=[{'name':'neutral','prob':1.,'assets':{'UST_10Y':{'shift_sd':0.,'vol_scale':1.}}}]
    result,_=transform(base,['UST_10Y'],np.array([[5,21,63]]),scenario,42)
    assert np.array_equal(base,result)

def test_cpi_only_hybrid_retains_other_series():
    panels,dates=fixture();asof=str(dates[219].date());steps=np.tile([1,3,9],(2,1))
    a,meta=forecast(panels,['CPI_ALL','NFP'],steps,asof,'level',512,42,True,'cpi_soft')
    control,_=fixed(panels,['CPI_ALL','NFP'],steps,asof,'level',512,42,True)
    assert np.array_equal(a[:,:,1],control[:,:,1])
    assert meta['engine']=='cpi_all_only_soft_hybrid'
