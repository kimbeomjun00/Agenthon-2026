"""## Executive summary (read this first)
Audit legitimate irregular inputs and the numerical information sent to House.
The same tests run against the submitted immutable image and the follow-up candidate.
"""
import json,pathlib,tomllib
import numpy as np
import pandas as pd
import pytest
from vnext.inflation import forecast
from vnext.specialists import prepare
from qfbench2_track_forecasting.cli import _read_panels,_series

def panel(dates,values,assets):
    return {'p':pd.DataFrame({'date':np.repeat(dates,len(assets)),
        'asset':np.tile(assets,len(dates)),'value':np.asarray(values).reshape(-1),'panel_id':'test'})}

def test_monthly_same_period_different_observation_days():
    dates=pd.date_range('2000-01-01',periods=220,freq='MS')
    rng=np.random.default_rng(4);levels=100+np.cumsum(rng.normal(.25,.03,(220,2)),axis=0)
    p=panel(dates,levels,['CPI_ALL','CPI_CORE'])
    p['p'].loc[p['p']['asset']=='CPI_CORE','date']+=pd.Timedelta(days=14)
    s=prepare(p,['CPI_ALL','CPI_CORE'],'2018-04-30','level',True)
    assert len(s.x)==219
    sample,meta=forecast(p,['CPI_ALL','CPI_CORE'],np.tile([1,3,9],(2,1)),'2018-04-30','level',512,42,True)
    assert np.isfinite(sample).all()
    assert sample.shape==(512,3,2)

def test_old_internal_gap_is_not_a_single_daily_shock():
    dates=pd.bdate_range('2000-01-03',periods=1800)
    x=2+np.cumsum(np.random.default_rng(5).normal(0,.01,1800))
    x[800:]+=100
    keep=np.r_[np.arange(500),np.arange(800,1800)]
    p=panel(dates[keep],x[keep,None],['UST_10Y'])
    sample,meta=forecast(p,['UST_10Y'],np.array([[21,63]]),str(dates[-1].date()),'level',2000,42)
    assert sample[:,1,0].std()<.3
    assert abs(sample[:,1,0].mean()-x[-1])<.1

def test_reject_two_distinct_observations_in_one_month():
    dates=pd.date_range('2000-01-01',periods=220,freq='MS')
    p=panel(dates,np.arange(220)[:,None]+100.,['CPI_ALL'])
    extra=p['p'].iloc[0:1].copy();extra['date']+=pd.Timedelta(days=2)
    p={'p':pd.concat([p['p'],extra],ignore_index=True)}
    with pytest.raises(ValueError):prepare(p,['CPI_ALL'],'2018-04-30','level',True)

def test_house_receives_actual_anchor_and_volatility(monkeypatch,tmp_path):
    import vnext.cli as cli
    unit=pathlib.Path('/repo/V11/units/t2-F4-funding-stress-10y-2008')
    card=tomllib.loads((unit/'card.toml').read_text());asof=str(card['provenance']['data_cutoff'])
    captured={}
    original=cli.build_prompt
    def capture(family,assets,horizons,target,cutoff,anchors,stats,docs):
        captured.update(anchors=anchors,stats=stats)
        return original(family,assets,horizons,target,cutoff,anchors,stats,docs)
    monkeypatch.setattr(cli,'build_prompt',capture)
    monkeypatch.setattr(cli,'call_house',lambda prompt:(None,'audit; no actual House call'))
    cli.main(['--panels',str(unit/'panels'),'--text',str(unit/'text'),'--asof',asof,
              '--out',str(tmp_path/'forecast.parquet'),'--n-draws','512'])
    panels=_read_panels(unit/'panels');asset=card['targets']['asset_ids'][0]
    s=_series(panels,asset,asof)
    assert captured['anchors'][asset]==pytest.approx(float(s.iloc[-1]),rel=1e-12)
    ratio=captured['stats'][asset]['daily_sd_recent']/captured['stats'][asset]['daily_sd_full']
    assert abs(ratio-1.)>1e-3
