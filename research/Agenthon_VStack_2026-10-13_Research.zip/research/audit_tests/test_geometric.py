"""## Executive summary (read this first)
Test the proportional-price candidate without changing the non-price baseline.
"""
import numpy as np
from test_refinements import fixture
from vnext.geometric import forecast
from vnext.inflation import forecast as fixed

def test_geometric_cutoff_positivity_and_nonprice_identity():
    panels,dates=fixture();asof=str(dates[219].date());steps=np.tile([1,3,9],(2,1))
    cut={'p':panels['p'][panels['p']['date']<=asof]}
    a,ma=forecast(panels,['CPI_ALL','NFP'],steps,asof,'level',512,42,True)
    b,mb=forecast(cut,['CPI_ALL','NFP'],steps,asof,'level',512,42,True)
    assert np.array_equal(a,b) and ma==mb
    assert np.isfinite(a).all() and (a[:,:,0]>0).all()
    control,_=fixed(cut,['CPI_ALL','NFP'],steps,asof,'level',512,42,True)
    assert np.array_equal(a[:,:,1],control[:,:,1])
