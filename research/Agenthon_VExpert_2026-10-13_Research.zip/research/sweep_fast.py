"""## Executive summary (read this first)
Measure the post-comparison price-family composition separately on reused periods.
Do not call this an independently selected or confirmed winning model.
"""
import argparse
from experiment import run
p=argparse.ArgumentParser();p.add_argument('--profile',choices=['primary','sensitivity','dense','single'],required=True);a=p.parse_args()
for seed in [42,77]:
    run(argparse.Namespace(panel='macro',split='evaluation',draws=1000 if a.profile in ['dense','single'] else 2000,
        seed=seed,count=8 if a.profile=='single' else 0,horizons='1,3,6' if a.profile=='sensitivity' else '',
        assets='',single_all=a.profile=='single',stride=1 if a.profile=='dense' else 0,fast_only=True,
        out=f'/lab/results/fast_{a.profile}{seed}_macro'))
