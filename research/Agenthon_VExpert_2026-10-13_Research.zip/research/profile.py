"""## Executive summary (read this first)
Inspect the provided histories and record aggregate coverage/provenance, not target answers.
"""
import hashlib,json,pathlib,sys
import pandas as pd
sys.path.insert(0,'/oldlab')
from experiment import sources
rows=[]
for family,(path,frame,key) in sources(pathlib.Path('/repo/V11')).items():
    for asset,part in frame.groupby(key):
        dates=pd.to_datetime(part['date']).sort_values()
        rows.append({'family':family,'asset':asset,'rows':len(part),'start':str(dates.min().date()),
                     'end':str(dates.max().date()),'duplicate_dates':int(dates.duplicated().sum()),
                     'null_values':int(part['value'].isna().sum()),
                     'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
out=pathlib.Path('/lab/DATA_COVERAGE.json')
out.write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
