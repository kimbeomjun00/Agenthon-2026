# ## Executive summary (read this first)
# Reproduce domain experts without replacing any submitted ZIP or registry image.
param(
  [Parameter(Mandatory=$true)][string]$RepositoryRoot,
  [ValidateSet('All','Validate','Development','Evaluation','Sensitivity','Single','Mixed','Dense','Fast')][string]$Phase='All',
  [ValidatePattern('^[A-Za-z0-9_-]+$')][string]$RunPrefix='repro'
)
$ErrorActionPreference='Stop'
$bundleRoot=Split-Path -Parent $PSScriptRoot
$repo=(Resolve-Path -LiteralPath $RepositoryRoot).Path
$lab=(Resolve-Path -LiteralPath $PSScriptRoot).Path
$baseline=(Resolve-Path -LiteralPath (Join-Path $bundleRoot 'VSpecial_baseline')).Path
$legacy=(Resolve-Path -LiteralPath (Join-Path $lab 'legacy')).Path
$tests=(Resolve-Path -LiteralPath (Join-Path $bundleRoot 'VExpert/tests')).Path
if (!(Test-Path -LiteralPath (Join-Path $repo 'V11/units'))) { throw 'RepositoryRoot must contain V11/units' }
docker build --platform linux/amd64 -t agenthon-vexpert:research (Join-Path $bundleRoot 'VExpert')
if ($LASTEXITCODE -ne 0) { throw 'Research image build failed' }
$mounts=@('--rm','--network','none','--cpus','4','--memory','4g','-e','OPENBLAS_NUM_THREADS=1',
 '--mount',"type=bind,source=$repo,target=/repo,readonly",
 '--mount',"type=bind,source=$lab,target=/lab",
 '--mount',"type=bind,source=$baseline,target=/baseline,readonly",
 '--mount',"type=bind,source=$legacy,target=/oldlab,readonly",
 '--mount',"type=bind,source=$tests,target=/tests,readonly")
if ($Phase -in @('All','Validate')) {
  docker run @mounts agenthon-vexpert:research python -m pytest /tests /lab/test_experts.py `
    /lab/audit_tests/test_audit_cases.py /lab/audit_tests/test_refinements.py /lab/audit_tests/test_geometric.py -q -p no:cacheprovider
  if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed' }
  docker run @mounts agenthon-vexpert:research python /lab/validate.py --mode expert `
    --units /repo/V11/units --out "/lab/results/${RunPrefix}_gates" --draws 2000
  if ($LASTEXITCODE -ne 0) { throw 'Public output gates failed' }
  docker run @mounts agenthon-vexpert:research python /lab/validate.py --mode fast_price `
    --units /repo/V11/units --out "/lab/results/${RunPrefix}_gates_fast_price" --draws 2000
  if ($LASTEXITCODE -ne 0) { throw 'Fast-price public output gates failed' }
}
if ($Phase -in @('All','Dense','Fast')) {
  foreach ($seed in @(42,77)) {
    if ($Phase -in @('All','Dense')) {
      docker run @mounts agenthon-vexpert:research python /lab/experiment.py --panel macro --split evaluation `
        --stride 1 --draws 1000 --seed $seed --out "/lab/results/${RunPrefix}_Dense_${seed}"
      if ($LASTEXITCODE -ne 0) { throw 'Dense macro comparison failed' }
    }
    if ($Phase -in @('All','Fast')) {
      foreach ($fastProfile in @('primary','sensitivity','dense','single')) {
        $extra=@();$draws='2000'
        if ($fastProfile -eq 'sensitivity') { $extra=@('--horizons','1,3,6') }
        if ($fastProfile -eq 'dense') { $extra=@('--stride','1');$draws='1000' }
        if ($fastProfile -eq 'single') { $extra=@('--single-all','--count','8');$draws='1000' }
        docker run @mounts agenthon-vexpert:research python /lab/experiment.py --panel macro --split evaluation `
          --fast-only --draws $draws --seed $seed --out "/lab/results/${RunPrefix}_Fast_${fastProfile}_${seed}" @extra
        if ($LASTEXITCODE -ne 0) { throw 'Post-comparison fast hybrid failed' }
      }
    }
  }
}
if ($Phase -in @('All','Mixed')) {
  foreach ($seed in @(42,77)) {
    docker run @mounts agenthon-vexpert:research python /lab/mixed_experiment.py --draws 1000 `
      --count 8 --seed $seed --out "/lab/results/${RunPrefix}_Mixed_${seed}"
    if ($LASTEXITCODE -ne 0) { throw 'Mixed-domain comparison failed' }
  }
}
foreach ($phaseName in @('Development','Evaluation','Sensitivity','Single')) {
  if ($Phase -ne 'All' -and $Phase -ne $phaseName) { continue }
  $seeds=@(42,77)
  if ($phaseName -eq 'Development') { $seeds=@(42) }
  foreach ($panel in @('rates','fx','factors','macro')) {
    foreach ($seed in $seeds) {
      $split='evaluation';$draws='2000';$count='0';$extra=@()
      if ($phaseName -eq 'Development') { $split='development';$draws='512';$count='36' }
      if ($phaseName -eq 'Sensitivity') {
        $extra=@('--horizons','5,21');$count='36'
        if ($panel -eq 'macro') { $extra=@('--horizons','1,3,6') }
      }
      if ($phaseName -eq 'Single') { $extra=@('--single-all');$count='8';$draws='1000' }
      $label="${RunPrefix}_${phaseName}_${seed}_${panel}"
      docker run @mounts agenthon-vexpert:research python /lab/experiment.py --panel $panel `
        --split $split --draws $draws --count $count --seed $seed --out "/lab/results/$label" @extra
      if ($LASTEXITCODE -ne 0) { throw "Experiment failed: $label" }
    }
  }
}
# Each result path is immutable. Use a fresh RunPrefix to repeat a phase.
# analyze.py needs host Python with pandas/numpy. Analyze each phase separately;
# never merge Single/Joint or different horizon grids. Source panels are not in this ZIP.
