"""## Executive summary (read this first)
Average seeds within origins; compare every expert and the integrated router with VSpecial.
Different target-set/horizon profiles must be analyzed separately.
"""
import argparse,json,pathlib
import numpy as np
import pandas as pd

def main(args):
    root=pathlib.Path(args.root);out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    dirs=[p for pattern in args.patterns.split(',') for p in root.glob(pattern) if (p/'asset_metrics.csv').is_file()]
    a=pd.concat([pd.read_csv(p/'asset_metrics.csv') for p in dirs],ignore_index=True)
    j=pd.concat([pd.read_csv(p/'joint_metrics.csv') for p in dirs],ignore_index=True)
    assert a['profile'].nunique()==1,'Do not combine joint-panel and single-target profiles'
    keys=['panel','asset','asof','model'];joint_keys=['panel','target_set','asof','model']
    assert not a.duplicated(keys+['seed']).any(),'Repeated case/seed would double-count evidence'
    a=a.groupby(keys).mean(numeric_only=True).reset_index();j=j.groupby(joint_keys).mean(numeric_only=True).reset_index()
    columns=['crps_scaled','local_composite','marginal','joint','tail','coverage90']
    am=a.groupby(['panel','asset','model'])[columns].mean().reset_index()
    jm=j.groupby(['panel','target_set','model'])[columns].mean().reset_index()
    b=am[am['model']=='submitted'].set_index(['panel','asset']);jb=jm[jm['model']=='submitted'].set_index(['panel','target_set'])
    for metric in columns[:-1]:
        am['gain_'+metric]=[1-r[metric]/b.loc[(r['panel'],r['asset']),metric] for _,r in am.iterrows()]
        jm['gain_'+metric]=[1-r[metric]/jb.loc[(r['panel'],r['target_set']),metric] for _,r in jm.iterrows()]
    am.to_csv(out/'asset_summary.csv',index=False);jm.to_csv(out/'panel_summary.csv',index=False)
    uncertainty=[]
    for (panel,asset),grp in a.groupby(['panel','asset']):
        pivot=grp.pivot(index='asof',columns='model',values='crps_scaled');years=pd.to_datetime(pivot.index).year
        blocks=sorted(set(years));draw=np.random.default_rng(732).integers(len(blocks),size=(3000,len(blocks)))
        for model in pivot.columns:
            if model=='submitted':continue
            valid=pivot[['submitted',model]].dropna()
            totals=np.array([[pivot.loc[years==year,model].sum(),pivot.loc[years==year,'submitted'].sum()] for year in blocks])
            sums=totals[draw].sum(axis=1);boot=1-sums[:,0]/sums[:,1];lo,hi=np.quantile(boot,[.025,.975])
            uncertainty.append({'panel':panel,'asset':asset,'model':model,'cases':len(valid),'year_blocks':len(blocks),
                'gain':1-valid[model].mean()/valid['submitted'].mean(),'ci_low':lo,'ci_high':hi,
                'win_rate':float(np.mean(valid[model]<valid['submitted']))})
    pd.DataFrame(uncertainty).to_csv(out/'uncertainty.csv',index=False)
    selections=[]
    for p in dirs:
        manifest=json.loads((p/'run.json').read_text());seed=manifest['seed']
        for row in json.loads((p/'selections.json').read_text()):
            meta=row['metadata']
            for asset in row['targets']:
                weights=meta.get('asset_weights',{}).get(asset,{'baseline':1.})
                model_name=meta.get('asset_models',{}).get(asset,'baseline')
                active=(weights.get('baseline',0)<.999999) if 'asset_weights' in meta else ('baseline' not in model_name.lower())
                selections.append({'panel':manifest['panel'],'asof':row['asof'],'asset':asset,'seed':seed,
                    'active':float(active),'folds':meta.get('folds',0)})
    pd.DataFrame(selections).groupby(['panel','asset'])[['active','folds']].mean().reset_index().to_csv(out/'router_activity.csv',index=False)
    (out/'analysis.json').write_text(json.dumps({'runs':[p.name for p in dirs],
        'cases_per_panel':a.groupby('panel')['asof'].nunique().to_dict(),
        'profile':str(pd.read_csv(dirs[0]/'asset_metrics.csv')['profile'].iloc[0]),
        'overlapping_windows':any(json.loads((p/'run.json').read_text()).get('overlapping_windows',False) for p in dirs),
        'meaning':'exploratory seed-averaged paired origins; few year blocks; overlapping windows are not independent; not selection-adjusted significance or official M0 score'},indent=2))
    print(jm[jm['model'].isin(['integrated','integrated_open'])][['panel','target_set','model','gain_crps_scaled','gain_local_composite','coverage90']].to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='expert-lab/results');p.add_argument('--patterns',required=True)
    p.add_argument('--out',required=True);main(p.parse_args())
