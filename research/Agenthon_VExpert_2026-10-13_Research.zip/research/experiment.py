"""## Executive summary (read this first)
Evaluate every applicable expert per asset and the actual integrated past-only router.
Save local losses and aggregate diagnostics, never publish future values or forecasts.
"""
import argparse,hashlib,importlib,importlib.util,json,pathlib,sys,time,warnings
import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from qfbench2_track_forecasting.cli import _draw
from vnext.experts import candidates,context_state,expand_steps,menu,forecast,mix
from vnext.specialists import _scale
from vnext.inflation import forecast as safe
spec=importlib.util.spec_from_file_location('submitted_vnext','/baseline/vnext/__init__.py',submodule_search_locations=['/baseline/vnext'])
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
submitted=importlib.import_module('submitted_vnext.inflation').forecast
legacy_spec=importlib.util.spec_from_file_location('legacy_measure','/oldlab/experiment.py')
legacy=importlib.util.module_from_spec(legacy_spec);legacy_spec.loader.exec_module(legacy)
warnings.filterwarnings('ignore',category=UserWarning)


def run(args):
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    path,df,acol=legacy.sources(pathlib.Path('/repo/V11'))[args.panel]
    all_assets=sorted(df[acol].unique());assets=args.assets.split(',') if args.assets else all_assets
    monthly=args.panel=='macro';target='log_return' if args.panel=='factors' else 'level'
    hs=np.array(list(map(int,args.horizons.split(',')))) if args.horizons else np.array([1,3,9] if monthly else [5,21,63])
    wide=df[df[acol].isin(assets)].pivot(index='date',columns=acol,values='value').reindex(columns=assets).dropna()
    maximum=int(hs.max());minimum=84 if monthly else 750
    lo,hi=(2006,2019) if args.split=='development' else (2020,2024)
    eligible=np.flatnonzero((wide.index.year>=lo)&(wide.index.year<=hi)&(np.arange(len(wide))>=minimum)&(np.arange(len(wide))+maximum<len(wide)))
    indices=[]
    stride=getattr(args,'stride',0) or maximum
    for ix in eligible:
        if not indices or ix-indices[-1]>=stride:indices.append(int(ix))
    if args.count and len(indices)>args.count:
        indices=[indices[i] for i in np.unique(np.linspace(0,len(indices)-1,args.count).round().astype(int))]
    rows=[];joint=[];selections=[];t=time.monotonic()
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/opt/vnext').glob('*.py')}
    cache=None
    if args.single_all:
        import vnext.experts as expert_module
        from cache_utils import CandidateCache
        cache=CandidateCache(candidates);expert_module.candidates=cache
    for case,ix in enumerate(indices):
        if cache is not None:cache.clear()
        cutoff=wide.index[ix];asof=str(cutoff.date());panels={args.panel:df[df['date']<=cutoff].copy()}
        targets=[[a] for a in assets] if args.single_all else [assets]
        for target_assets in targets:
            ia=[assets.index(a) for a in target_assets];steps=np.tile(hs,(len(target_assets),1))
            state=context_state(panels,target_assets,asof,target,monthly);context_indices=[state.assets.index(a) for a in target_assets]
            if args.single_all:
                own=df[df[acol].isin(target_assets)].pivot(index='date',columns=acol,values='value').reindex(columns=target_assets).dropna()
                future=own.loc[own.index>cutoff].iloc[:maximum].to_numpy(float)
            else:future=wide.iloc[ix+1:ix+maximum+1].to_numpy(float)[:,ia]
            truth=np.stack([np.log1p(future[:h]).sum(axis=0) if target=='log_return' else future[h-1] for h in hs])
            scale=np.maximum(_scale(state.x[:,context_indices])*np.sqrt(hs[:,None]),1e-8)
            original,_=submitted(panels,target_assets,steps,asof,target,args.draws,args.seed,monthly)
            repaired,_=safe(panels,target_assets,steps,asof,target,args.draws,args.seed,monthly)
            generator=cache if cache is not None else candidates
            if getattr(args,'fast_only',False):
                from vnext.fast_price import forecast as hybrid_forecast
                hybrid,meta=hybrid_forecast(panels,target_assets,steps,asof,target,args.draws,args.seed,monthly)
                sims={'fast_hybrid':hybrid}
            else:
                sims={k:v[:,:,context_indices] for k,v in generator(state,expand_steps(state,target_assets,steps),args.draws,args.seed).items()}
            # Full-panel diagnostics replace inapplicable columns with the actual baseline.
            for name,sample in sims.items():
                for ai,a in enumerate(target_assets):
                    if name!='fast_hybrid' and name not in menu(a,state.assets):sample[:,:,ai]=original[:,:,ai]
            if not getattr(args,'fast_only',False):integrated,meta=forecast(panels,target_assets,steps,asof,target,args.draws,args.seed,monthly)
            else:integrated=hybrid
            open_sample=repaired
            if not getattr(args,'fast_only',False) and 'unguarded_asset_weights' in meta:
                names=['baseline']+list(sims)
                weights=np.array([[meta['unguarded_asset_weights'][a].get(k,0.) for a in target_assets] for k in names])
                open_sample=mix({'baseline':repaired,**sims},names,weights,steps,args.seed)
            sims={'submitted':original,'safe':repaired,**sims} if getattr(args,'fast_only',False) else {'submitted':original,'safe':repaired,**sims,'integrated':integrated,'integrated_open':open_sample}
            selections.append({'asof':asof,'targets':target_assets,'metadata':meta})
            reference,_=_draw(panels,target_assets,hs.tolist(),asof,args.draws,args.seed+191,target_type=target,panel_steps=steps if monthly else None)
            reference=reference.transpose(0,2,1);rs=legacy.expectation_scale(reference,args.seed)
            ars=[legacy.expectation_scale(reference[:,:,i:i+1],args.seed) for i in range(len(target_assets))]
            for mode,sample in sims.items():
                scores=legacy.composite(sample,truth);crps=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
                low,high=np.quantile(sample,[.05,.95],axis=0)
                row={'case':case,'panel':args.panel,'asof':asof,'model':mode,'seed':args.seed,'draws':args.draws,
                     'profile':'single_with_context' if args.single_all else 'joint_panel',
                     'target_set':','.join(target_assets),'crps_scaled':float(np.mean(crps/scale)),
                     'local_composite':sum(w*scores[k]/rs[k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                     'coverage90':float(np.mean((truth>=low)&(truth<=high)))}
                joint.append(row|{k:scores[k] for k in ('marginal','joint','tail')})
                for ai,a in enumerate(target_assets):
                    if mode not in ('submitted','safe','integrated','integrated_open','fast_hybrid') and mode not in menu(a,state.assets):continue
                    per=legacy.composite(sample[:,:,ai:ai+1],truth[:,ai:ai+1])
                    rows.append(row|{'asset':a,'crps_scaled':float(np.mean(crps[:,ai]/scale[:,ai])),
                         'coverage90':float(np.mean((truth[:,ai]>=low[:,ai])&(truth[:,ai]<=high[:,ai]))),
                         'local_composite':sum(w*per[k]/ars[ai][k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                         **{k:per[k] for k in ('marginal','joint','tail')}})
        pd.DataFrame(rows).to_csv(out/'asset_metrics.csv',index=False)
        pd.DataFrame(joint).to_csv(out/'joint_metrics.csv',index=False)
        print(args.panel,args.split,case+1,len(indices),asof,f'{time.monotonic()-t:.1f}s',flush=True)
    a=pd.DataFrame(rows);j=pd.DataFrame(joint)
    a.groupby(['panel','asset','model']).mean(numeric_only=True).reset_index().to_csv(out/'asset_summary.csv',index=False)
    j.groupby(['panel','target_set','model']).mean(numeric_only=True).reset_index().to_csv(out/'joint_summary.csv',index=False)
    (out/'selections.json').write_text(json.dumps(selections,indent=2))
    (out/'run.json').write_text(json.dumps(vars(args)|{'cases':len(indices),'assets':assets,'model_hashes':hashes,
         'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seconds':time.monotonic()-t,
         'overlapping_windows':stride<maximum,
         'cache':{'hits':cache.hits,'misses':cache.misses} if cache else None,
         'label':'exploratory domain-specific numeric backtest, not Codabench; macro revised vintage'},indent=2))
    print(j.groupby('model')[['crps_scaled','local_composite']].mean().to_string(),flush=True)
    if cache is not None:expert_module.candidates=candidates


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--panel',choices=['rates','fx','factors','macro'],required=True)
    p.add_argument('--split',choices=['development','evaluation'],default='development')
    p.add_argument('--count',type=int,default=0);p.add_argument('--draws',type=int,default=512);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--horizons',default='');p.add_argument('--assets',default='');p.add_argument('--single-all',action='store_true')
    p.add_argument('--stride',type=int,default=0)
    p.add_argument('--fast-only',action='store_true')
    p.add_argument('--out',required=True);run(p.parse_args())
