## Executive summary (read this first)

Design and compare domain-specific numerical experts for every supplied series, then test
the integrated cutoff-local router, not merely the best hindsight candidate.
The original VSpecial submission and all previous research remain unchanged.

This protocol is frozen before the new candidate runs. The already explored 2020-2024
period remains exploratory; no pristine holdout or Codabench uplift is claimed.

### Models and roles

- Rates: native yield changes, Nelson-Siegel curve state, PCA change factors, damped
  policy-cycle trend, conditional changes, and filtered/asymmetric variance.
- FX: positive log-price random walk, filtered residual volatility, common currency
  factors, shrinkage conditional changes, and DKK/EUR spread mean reversion when
  the supplied EUR history exists. No hardcoded historical event dates.
- Factors: cumulative log1p returns, asset-role mean priors estimated from current
  history, asset-role-specific lagged return/crash-rebound/calendar conditions,
  lagged multivariate conditions, asymmetric variance, and daily/weekly/monthly
  squared-return variance proxy. This is NOT intraday realized-volatility HAR-RV.
- Macro: log CPI/PCE growth, slow/fast Kalman trend, growth persistence, seasonal
  growth, robust employment changes, bounded unemployment state, and cross-series
  conditional changes. Do not claim GDP accuracy without an actual supplied GDP history.

Every applicable candidate is recorded separately for each asset. A candidate needs
available input features; unavailable models are not silently called validated experts.
Context covariates come only from the same supplied panel family before the cutoff.

### Evaluation

- Development: 2006-2019, up to 36 daily nonoverlapping origins and all monthly origins,
  512 draws. Design uses economic/statistical structure, not subsequent-period rankings.
- Primary subsequent evaluation: 2020-2024, all origins with nonoverlapping maximum
  horizon windows, 2000 draws, seeds 42 and 77. Daily [5,21,63]; monthly [1,3,9].
- Sensitivity: daily [5,21], monthly [1,3,6], at most 36 daily origins, seeds 42/77.
  These windows can overlap primary windows and are not independent validation events.
- Joint target panels and single-target-with-context profiles are distinguished.
- Report per-asset volatility-scaled CRPS, canonical variogram/tail pinball, 90% coverage,
  integrated panel results, year blocks and paired wins. Seed repetitions are first averaged
  within the same origin. Extreme macro shocks are retained, not excluded from scoring.
- No per-card realized outcomes, future values, raw panels or individual forecasts are
  published. Per-origin losses are local research evidence only, excluded from public ZIP.

### Runtime integration

Fit parameters and choose models from fully resolved folds of this unit's history only.
Use a fixed asset-role menu, six recent nonoverlapping folds and conservative gain/win
guards. Preserve baseline probability mass and joint per-step innovations. Test the
resulting full distribution against the actual submitted VSpecial numerical baseline.
No fitted regression parameters, benchmark winner table or outcome lookup is deployed.

Use supplied rows only, preserve source-date cutoff before monthly alignment, do not
bridge missing periods, retain actual monthly step matrices and output horizon keys.
All output scoring is imported from the pinned official packages, never rewritten.
LLM/House plumbing remains on the organizer-only client. Real House accuracy is untested.

### Model references

The experts are parsimonious adaptations, not exact reproductions of the papers:

- [Diebold/Li/Yue dynamic Nelson-Siegel working paper](https://economics.sas.upenn.edu/sites/default/files/filevault/working-papers/07-030.pdf)
- [Corsi HAR-RV paper](https://statmath.wu.ac.at/~hauser/LVs/FinEtricsQF/References/Corsi2009JFinEtrics_LMmodelRealizedVola.pdf)
- [Engle/Ng asymmetric news-impact study](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1540-6261.1993.tb05127.x)
- [Official T2 rules](https://github.com/Agenthon-2026/track2-forecasting-public)
