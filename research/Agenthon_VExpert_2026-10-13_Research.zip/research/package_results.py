"""Package frozen model source and aggregate evidence, never outcomes or credentials.

Requires completed final-image QA and both 103-unit structural validation profiles.
Old sources, submitted artifacts and previous research bundles remain untouched.
"""
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET
import zipfile

BASE=Path(__file__).resolve().parent.parent
LAB=BASE/'expert-lab'
REPO=BASE/'agenthon-v11-work'
NAME='Agenthon_VExpert_2026-10-13_Research'
DEST=BASE/'artifacts'/NAME
ZIP=DEST.with_suffix('.zip')
IMAGE='sha256:4667c9dc85f36407103f91d2b8c0ee421d80880226a3c0464def849e95670fee'
MODEL_HASHES={
    'experts.py':'3f64a448d5ccf6ccd03210fcd34acfc7611b34b16d37c8160bf9a1078d27bc84',
    'portfolio.py':'9f295f366598e822aa8e8f9e675f4838cf6d07c44eae68f3e7c46325848f1707',
    'fast_price.py':'e3d65a6f3080d2e0bfe4521385e5273f93b7cc455537605281f6479473634843',
}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def copy_file(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)

def copy_source(source,target):
    for path in sorted(source.rglob('*')):
        rel=path.relative_to(source)
        if not path.is_file() or any(p.startswith('.') or p=='__pycache__' for p in rel.parts):continue
        if path.suffix not in {'.py','.md','.lock','.ps1'} and path.name not in {'Dockerfile','TOOLKIT-LICENSE','OFFICIAL-MIT-LICENSE'}:continue
        copy_file(path,target/rel)

def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def main():
    assert not DEST.exists() and not ZIP.exists(),'Never overwrite an earlier research bundle'
    delivery=LAB/'delivery_ready'
    verified=json.loads((delivery/'ANALYSIS_VERIFICATION.json').read_text())
    assert verified['assets']==28 and verified['expert_settings']==18 and verified['asset_candidate_pairs']==173
    baseline=REPO/'VSpecial'
    known=json.loads(Path('C:/Users/kimbu/Desktop/VSPECIAL_SUBMISSION_READY/SOURCE_HASHES.json').read_text())
    assert all(digest(baseline/name)==sha for name,sha in known.items())
    original_zip=Path('C:/Users/kimbu/Desktop/VSPECIAL_SUBMISSION_READY/submission_vspecial_final.zip')
    submitted_hash=digest(original_zip)
    assert submitted_hash=='a1c291aa845cfbc75db65710beb37fb0e1e5c153afe9edb40531630b3f607821'
    model=REPO/'VExpert'
    assert all(digest(model/'vnext'/name)==sha for name,sha in MODEL_HASHES.items())
    official_hashes={p.name:digest(p) for p in (model/'qfbench2_track_forecasting').glob('*.py')}
    assert all(digest(BASE/'official-track2/qfbench2_track_forecasting'/name)==sha for name,sha in official_hashes.items())
    assert digest(model/'requirements.lock')==digest(REPO/'VSpecial2/requirements.lock')
    qa=ET.parse(LAB/'results/qa_final.xml').getroot().find('testsuite')
    assert qa is not None and int(qa.attrib['failures'])==int(qa.attrib['errors'])==0
    gate_records=verified['validation_modes']
    assert all(g['image_id']==IMAGE and g['passed']==g['units']==103 for g in gate_records.values())
    current_hashes={p.name:digest(p) for p in (model/'vnext').glob('*.py')}
    analysis_dirs=[LAB/'results'/f'{p}_analysis' for p in verified['independent_checks']]
    run_names=sorted({r for a in analysis_dirs for r in json.loads((a/'analysis.json').read_text())['runs']})
    for run in run_names:
        if run.startswith(('dev_','dev2_')):continue
        record=json.loads((LAB/'results'/run/'run.json').read_text())
        assert record['model_hashes']['experts.py']==MODEL_HASHES['experts.py'],run
        if run.startswith('mixed'):assert record['model_hashes']['portfolio.py']==MODEL_HASHES['portfolio.py'],run
        if run.startswith('fast_'):assert record['model_hashes']['fast_price.py']==MODEL_HASHES['fast_price.py'],run

    DEST.mkdir(parents=True)
    copy_source(model,DEST/'VExpert')
    copy_source(baseline,DEST/'VSpecial_baseline')
    research=DEST/'research';research.mkdir()
    for path in sorted(LAB.iterdir()):
        if path.is_file() and path.suffix in {'.py','.ps1','.md','.json'} and path.name not in {'PACKAGE_VERIFICATION.json'}:
            copy_file(path,research/path.name)
    copy_file(model/'validate.py',research/'validate.py')
    copy_file(BASE/'asset-lab/experiment.py',research/'legacy/experiment.py')
    for name in ['test_audit_cases.py','test_refinements.py','test_geometric.py']:
        copy_file(BASE/'audit-lab'/name,research/'audit_tests'/name)
    copy_file(delivery/'SUMMARY_KR.md',DEST/'READ_ME_FIRST_KR.md')
    copy_file(delivery/'ASSET_RESULTS_28.csv',DEST/'ASSET_RESULTS_28.csv')
    copy_file(delivery/'ANALYSIS_VERIFICATION.json',DEST/'ANALYSIS_VERIFICATION.json')

    whitelist={'asset_summary.csv','joint_summary.csv','run.json','panel_summary.csv',
               'uncertainty.csv','router_activity.csv','analysis.json','summary.json','gates.csv','result.json'}
    folders=run_names+[p.name for p in analysis_dirs]+[
        'gates_fast_recovery','gates_expert_recovery','container_fast_recovery','container_expert_recovery']
    for name in folders:
        folder=LAB/'results'/name
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.name in whitelist:copy_file(path,research/'results'/name/path.name)
    copy_file(LAB/'results/qa_final.xml',research/'results/qa_final.xml')
    combined=[]
    for folder in analysis_dirs:
        meta=json.loads((folder/'analysis.json').read_text())
        for scope,file in [('asset','asset_summary.csv'),('target_set','panel_summary.csv')]:
            for row in read_csv(folder/file):
                combined.append({'profile':folder.name,'scope':scope,'origin_count':meta['cases_per_panel'][row['panel']],
                                 'baseline':'submitted_VSpecial','official_score':False,**row})
    fields=['profile','scope','panel','asset','target_set','model','origin_count','baseline','official_score',
            'crps_scaled','gain_crps_scaled','local_composite','gain_local_composite','marginal','gain_marginal',
            'joint','gain_joint','tail','gain_tail','coverage90']
    with (DEST/'ALL_AGGREGATE_RESULTS.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(combined)
    provenance={
        'date':'2026-10-13','purpose':'domain-specific research, not a Codabench submission',
        'submitted_image':'docker.io/kbj710211/agenthon-t2-v11@sha256:68d85e885da895a9559996675a44f5bbae289538dd03be1ecc0f97e959d6e821',
        'submitted_zip_sha256_unchanged':submitted_hash,'verified_baseline_source_hashes':known,
        'local_research_image':'agenthon-vexpert:research','local_image_id':IMAGE,
        'current_vnext_hashes':current_hashes,'frozen_numerical_components':MODEL_HASHES,
        'code_revision_scope':'Pure experts frozen before primary evaluation; mixed dispatcher separately frozen; fast_price composition selected AFTER earlier comparisons. Each run retains its exact module hashes.',
        'qa':{'tests_passed':int(qa.attrib['tests']),'tests_failed':0,'tests_errors':0,
              'public_output_gate_modes':gate_records,'offline_readonly_smoke_each_mode':[4,4]},
        'execution_recovery':'Docker/WSL service stopped with unexpected EOF during two validation runs. Restarted Docker without data reset. Valid completed same-image outputs were copied into fresh directories and regated; remaining units and every mock regenerated. A separate relative-path smoke helper error was corrected before final 4/4 runs.',
        'independent_csv_checks':verified['independent_checks'],'experiment_runs_included':run_names,
        'statistical_scope':'Seeds 42/77 averaged within origins; profiles/horizon grids not merged; overlapping monthly windows not independent; year-block intervals exploratory and not selection-adjusted.',
        'limitations':['2020-2024 already explored; no pristine holdout','post-comparison fast_price composition reuses selection periods',
                      'single revised macro vintage, not first-release realtime','GDP unavailable','CNY/INR/BRL early transfer only; not included in the 28 validated histories',
                      'no actual House accuracy test','local reference-scaled losses not official M0/Codabench','no blanket new-model superiority'],
        'official_track2_commit':'a2c93e7b66b8c6a6c429fda81d6bc7873b7c5dec','official_common_version':'2.6.0',
        'official_common_commit':'bd01548e34d21fd660d88fd06157078fb25ece4e','official_artifact_policy_revision':'2026-09-21.1',
        'official_track_helpers_sha256_unchanged':official_hashes,
        'excluded':['raw panels','individual forecasts','answer values','per-case losses','offline model winner tables for deployment',
                    'submission descriptor','team claim','credentials','Docker host logs'],
    }
    write_json(DEST/'provenance.json',provenance)
    secret=re.compile(rb'(?:ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
    forbidden={'asset_metrics.csv','joint_metrics.csv','selections.json','submission.json','team-claim.json'}
    for path in DEST.rglob('*'):
        if not path.is_file():continue
        assert not secret.search(path.read_bytes()),path.name
        assert path.suffix not in {'.parquet','.zip'} and path.name not in forbidden,path.name
        assert 'outputs' not in path.relative_to(DEST).parts,path
    manifest={p.relative_to(DEST).as_posix():digest(p) for p in sorted(DEST.rglob('*')) if p.is_file()}
    write_json(DEST/'MANIFEST.json',manifest)
    with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(DEST.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(DEST).as_posix())
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(name)).hexdigest()==sha for name,sha in manifest.items())
    result={'zip':str(ZIP),'bytes':ZIP.stat().st_size,'sha256':digest(ZIP),'files':len(manifest)+1,
            'aggregate_rows':len(combined),'profiles_verified':len(analysis_dirs),'not_submission':True,'credentials_or_answers_included':False}
    write_json(LAB/'PACKAGE_VERIFICATION.json',result)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
