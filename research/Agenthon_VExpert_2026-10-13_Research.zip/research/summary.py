"""## Executive summary (read this first)
Recompute reviewed aggregates independently and generate the complete 28-asset handoff.
Keep development winners, hindsight winners and deployable integration clearly separate.
"""
import csv,json,math,pathlib
from statistics import fmean
import xml.etree.ElementTree as ET

ROOT=pathlib.Path(__file__).resolve().parent
RESULTS=ROOT/'results'
OUT=ROOT/'delivery_ready'
PROFILES=['development','evaluation','sensitivity','single','dense','mixed','fast_primary','fast_sensitivity','fast_dense','fast_single']
CONTROLS={'submitted','safe','integrated','integrated_open'}

def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def independent_check(folder):
    meta=json.loads((folder/'analysis.json').read_text());checks=0
    for raw,summary,dimension in [('asset_metrics.csv','asset_summary.csv','asset'),('joint_metrics.csv','panel_summary.csv','target_set')]:
        events={}
        for run in meta['runs']:
            for row in read(RESULTS/run/raw):
                key=(row['panel'],row[dimension],row['asof'],row['model'])
                events.setdefault(key,[]).append(float(row['crps_scaled']))
        grouped={}
        for (panel,dim,asof,model),values in events.items():grouped.setdefault((panel,dim,model),[]).append(fmean(values))
        for row in read(folder/summary):
            key=(row['panel'],row[dimension],row['model']);mean=fmean(grouped[key])
            base=fmean(grouped[(key[0],key[1],'submitted')])
            assert math.isclose(mean,float(row['crps_scaled']),abs_tol=1e-12,rel_tol=1e-12),key
            assert math.isclose(1-mean/base,float(row['gain_crps_scaled']),abs_tol=1e-12),key
            checks+=1
    return checks

def gain(rows,asset,model,metric='gain_crps_scaled'):
    row=next(r for r in rows if r['asset']==asset and r['model']==model)
    return 100*float(row[metric])

def percent(value):
    return '0.00%' if abs(value)<.0005 else f'{value:+.2f}%'

def main():
    assert not OUT.exists(),'Preserve previous reports; use a new output path'
    qa=ET.parse(RESULTS/'qa_final.xml').getroot().find('testsuite')
    assert qa is not None and int(qa.attrib['failures'])==0 and int(qa.attrib['errors'])==0
    qa_count=int(qa.attrib['tests'])
    gates={mode:json.loads((RESULTS/f'gates_{mode}_recovery'/'summary.json').read_text()) for mode in ['expert','fast']}
    assert all(g['units']==g['passed']==103 and len(g['mocks'])==4 and all(m['ok'] for m in g['mocks']) for g in gates.values())
    for mode in ['expert','fast']:
        smoke=json.loads((RESULTS/f'container_{mode}_recovery'/'result.json').read_text())
        assert len(smoke)==4 and all(r['forecast_exit']==r['gate_exit']==0 and len(r['files'])==3 for r in smoke)
    checks={p:independent_check(RESULTS/f'{p}_analysis') for p in PROFILES}
    tables={p:read(RESULTS/f'{p}_analysis/asset_summary.csv') for p in PROFILES}
    panels={p:read(RESULTS/f'{p}_analysis/panel_summary.csv') for p in PROFILES}
    activity=read(RESULTS/'evaluation_analysis/router_activity.csv')
    decisions=[]
    assets=sorted({r['asset'] for r in tables['evaluation']})
    for a in assets:
        development=[r for r in tables['development'] if r['asset']==a and (r['model'] not in CONTROLS or r['model']=='submitted')]
        best=min(development,key=lambda r:float(r['crps_scaled']))
        evaluated=[r for r in tables['evaluation'] if r['asset']==a and (r['model'] not in CONTROLS or r['model']=='submitted')]
        hindsight=min(evaluated,key=lambda r:float(r['crps_scaled']))
        count=len([r for r in evaluated if r['model']!='submitted'])
        active=next(r for r in activity if r['asset']==a)
        decisions.append({'panel':best['panel'],'asset':a,'candidate_settings_tested':count,
            'development_best_model':best['model'],'development_gain_pct':100*float(best['gain_crps_scaled']),
            'development_model_primary_gain_pct':gain(tables['evaluation'],a,best['model']),
            'development_model_sensitivity_gain_pct':gain(tables['sensitivity'],a,best['model']),
            'integrated_primary_gain_pct':gain(tables['evaluation'],a,'integrated'),
            'integrated_sensitivity_gain_pct':gain(tables['sensitivity'],a,'integrated'),
            'integrated_single_target_gain_pct':gain(tables['single'],a,'integrated'),
            'runtime_active_pct':100*float(active['active']),
            'hindsight_primary_best_model_not_deployed':hindsight['model'],
            'hindsight_primary_gain_pct_not_deployed':100*float(hindsight['gain_crps_scaled']),
            'post_comparison_fast_hybrid_primary_gain_pct':gain(tables['fast_primary'],a,'fast_hybrid') if best['panel']=='macro' else gain(tables['evaluation'],a,'integrated'),
            'post_comparison_fast_hybrid_sensitivity_gain_pct':gain(tables['fast_sensitivity'],a,'fast_hybrid') if best['panel']=='macro' else gain(tables['sensitivity'],a,'integrated'),
            'post_comparison_fast_hybrid_single_gain_pct':gain(tables['fast_single'],a,'fast_hybrid') if best['panel']=='macro' else gain(tables['single'],a,'integrated')})
    assert len(decisions)==28
    configs=sorted({r['model'] for r in tables['evaluation'] if r['model'] not in CONTROLS})
    OUT.mkdir()
    with (OUT/'ASSET_RESULTS_28.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(decisions[0]));writer.writeheader();writer.writerows(decisions)
    lines=['# VExpert — 계열별 전문 모델 설계·통합 검증 결과','',
        '28계열 각각의 전문 후보를 설계·시험하고, 과거 정보만으로 고르는 통합 모델까지 구현했다. '+
        '**다만 기존 제출 VSpecial보다 안정적으로 더 좋은 통합 모델을 확보했다고 결론내릴 수는 없다.** '+
        '이 파일은 완료된 연구의 결과이며 제출용 ZIP이 아니다. 기존 제출 파일·이미지·Codabench는 변경하지 않았다.','',
        f'새 전문 후보 설정은 {len(configs)}개, 실제 계열×후보 비교 조합은 {sum(r["candidate_settings_tested"] for r in decisions)}개다. '+
        '서로 다른 속도·기간 설정을 포함한 수치이며, 18개의 완전히 독립적인 이론이라고 과장하지 않는다.','',
        '## 실제 통합 모델 결과','',
        '수치는 **제출 VSpecial의 수치 모델 대비 변동성 정규화 CRPS 손실 감소율**이다. 양수는 개선, 음수는 악화다. '+
        'House를 끈 인공 과거 구간 비교이며 공식 M0·Codabench 점수와 다르다.','',
        '| 패널 | 기본 기간 조합 | 기간 변경 |','| --- | ---: | ---: |']
    for family in ['rates','fx','factors','macro']:
        e=next(r for r in panels['evaluation'] if r['panel']==family and r['model']=='integrated')
        s=next(r for r in panels['sensitivity'] if r['panel']==family and r['model']=='integrated')
        lines.append(f'| {family} | {percent(100*float(e["gain_crps_scaled"]))} | {percent(100*float(s["gain_crps_scaled"]))} |')
    mixed=next(r for r in panels['mixed'] if r['model']=='integrated')
    dense=next(r for r in panels['dense'] if r['model']=='integrated')
    lines+=['',f'금리·FX 혼합 4계열(UST_2Y/10Y, EUR, JPY) 통합은 {percent(100*float(mixed["gain_crps_scaled"]))}. '+
        f'거시 45개 중첩 월별 시점에서는 CRPS {percent(100*float(dense["gain_crps_scaled"]))}, '+
        f'로컬 종합손실 {percent(100*float(dense["gain_local_composite"]))}였다. '+
        '중첩 시점 45개는 독립 사건 45개가 아니다.','',
        '## 추가 통합 후보 fast_price','',
        '28계열 비교를 마친 뒤 빠른 Kalman 필터가 CPI/PCE 네 계열에서 여러 평가 방식으로 좋아진 것을 확인했다. '+
        '이를 네 물가지수에 적용하고, NFP/UNRATE는 VSpecial 그대로, 일별 계열은 위의 검증된 expert 경로로 둔 '+
        '**추가 통합 연구 후보 fast_price**를 만들어 별도로 시험했다. 기본 expert와 같은 모델이라고 섞어 보고하지 않는다.','',
        '**조합 선택은 앞선 결과를 본 뒤 이루어졌다. 아래는 같은 기간을 재사용한 후속 실험이며 독립 확정 검증이 아니다.**','',
        '| 물가 계열 | 새 조합 기본 | 새 조합 기간 변경 | 새 조합 중첩 월별 |',
        '| --- | ---: | ---: | ---: |']
    for a in ['CPI_ALL','CPI_CORE','PCE_ALL','PCE_CORE']:
        lines.append(f'| {a} | {percent(gain(tables["fast_primary"],a,"fast_hybrid"))} | '+
            f'{percent(gain(tables["fast_sensitivity"],a,"fast_hybrid"))} | {percent(gain(tables["fast_dense"],a,"fast_hybrid"))} |')
    fp=next(r for r in panels['fast_primary'] if r['model']=='fast_hybrid')
    fs=next(r for r in panels['fast_sensitivity'] if r['model']=='fast_hybrid')
    fd=next(r for r in panels['fast_dense'] if r['model']=='fast_hybrid')
    lines+=['',f'거시 6계열 평균 CRPS 개선: 기본 {percent(100*float(fp["gain_crps_scaled"]))}, '+
        f'기간 변경 {percent(100*float(fs["gain_crps_scaled"]))}, 중첩 월별 {percent(100*float(fd["gain_crps_scaled"]))}. '+
        f'하지만 6계열 공동 입력의 로컬 종합손실 개선은 기본 {percent(100*float(fp["gain_local_composite"]))}로 작다. '+
        'NFP 등의 단위와 공동 손실의 영향이 크므로 개별 물가 개선을 전체 대회 점수 개선으로 표현하면 안 된다.','',
        '다른 거시 계열의 경로는 코드 검사에서 기존 값과 정확히 같았다. 일별·금리/FX 혼합 입력은 expert와 '+
        '같은 함수를 그대로 호출하므로 앞의 결과를 사용한다. 기본 실행 모드는 여전히 expert이고, '+
        '--mode fast_price는 별도 연구 옵션이다. 실제 제출 설정은 이번 ZIP에서 만들지 않았다.','',
        '## 28계열 전체 결과표','',
        '개발 최고는 2006–2019년 자료에서만 정한 비교 대상이다. 후속 열은 같은 후보의 2020–2024년 결과이고, '+
        '통합 열은 실제 과거 기반 선택기 결과다. 개발 승자를 미래에도 무조건 쓰거나, 후속 승자를 소급해 채택하지 않았다.','',
        '| 계열 | 후보 수 | 개발 최고 | 그 후보 후속 | 통합 기본 | 통합 기간 변경 | 통합 단독 입력 |',
        '| --- | ---: | --- | ---: | ---: | ---: | ---: |']
    for r in sorted(decisions,key=lambda r:(r['panel'],r['asset'])):
        lines.append(f'| {r["asset"]} | {r["candidate_settings_tested"]} | {r["development_best_model"]} | '+
            f'{percent(r["development_model_primary_gain_pct"])} | {percent(r["integrated_primary_gain_pct"])} | '+
            f'{percent(r["integrated_sensitivity_gain_pct"])} | {percent(r["integrated_single_target_gain_pct"])} |')
    lines+=['',
        '후속에서 가장 좋은 후보도 CSV에 남겼지만 **사후 최고값**으로 표시했고 배포 선택표로 사용하지 않았다. '+
        '후보별 손실과 실제 통합 손실의 차이는 선택·조합 단계가 여전히 중요하다는 근거다. '+
        '작은 최고값을 곧바로 새로운 모델의 확정 우월성으로 해석하지 않는다.','',
        '## 설계한 모델','',
        '| 영역 | 특징을 반영한 새 구조 |','| --- | --- |',
        '| 금리 | 만기별 수준·기울기·곡률 상태, 수익률곡선 PCA, 감쇠 정책 추세, 조건부 변화 회귀 |',
        '| FX | 양수 로그가격, 변동성 정규화 잔차, 공통 통화 요인, 조건부 변화, 인용 방향을 학습한 DKK/EUR 페그 |',
        '| MKT·HML·SMB·MOM·BAB·QMJ | 위험 프리미엄 평균 축소, 계열별 다른 lag·시장 급락/반등·계절 입력, 비대칭 변동성, 제곱수익률 일·주·월 분산 proxy |',
        '| CPI·PCE | 로그 증가율, 느린/빠른 Kalman 추세와 추세 불확실성, 변화 지속성·계절성·지표 간 회귀 |',
        '| NFP | 고용 수준의 변화, 강건한 추세·두 속도 상태 모형·지표 간 조건부 변화 |',
        '| UNRATE | 0–100 범위의 logit 상태, 평균회귀·추세·조건부 변화 |','',
        'HAR proxy는 일별 제곱수익률을 쓰며 장중 실현변동성 HAR-RV의 그대로 재현이 아니다. '+
        '각 모델은 이 단위의 과거 자료에서 다시 적합한다. 학습된 회귀 계수나 평가 승자 표를 이미지에 넣지 않는다.','',
        '## 통합 구조','',
        '단일 계열도 같은 공급 패널에 있는 보조 계열을 사용할 수 있다. 6개의 해결된 과거 창에서 계열별 후보를 비교하고, '+
        '3% 개선·60% 승률 조건과 공동 손실 점검을 거친다. 최소 35%의 기본 모델 비중과 별도 공통 20% 기본 경로 보험을 둔다. '+
        '따라서 기본 모델의 한계 확률질량은 기대상 최소 48%다. 정보가 부족하면 기본 모델 그대로 간다.','',
        '새 전문가는 공통 역사적 rank 충격을 쓰고, 혼합 금리·FX 입력은 영역별 적합 후 전체 경로를 공동 기준에 맞춰 정렬한다. '+
        '자산별 경로 전체를 옮겨 horizon 내부 구조를 유지하지만, 모든 기존 공분산을 정확히 보존한다는 주장은 아니다. '+
        '혼합 입력의 공동 손실을 별도 시험했다. 기본 연구 모드는 expert, 공동 보호 조건을 뺀 비교 모드는 expert_open이다.','',
        '## 검증 범위와 해석 한계','',
        '- 개발: 각 일별 패널 36개 비중첩 시점, 거시 18개, 512개 경로.',
        '- 기본 후속: 금리 19·FX 19·요인 17·거시 5개 비중첩 시점, 2,000개 경로, seed 42/77.',
        '- 기간 변경: 각 일별 패널 36개·거시 8개 시점, 2,000개 경로, 두 seed.',
        '- 단독 목표: 각 일별 계열 8개·거시 계열 5개 시점, 1,000개 경로, 두 seed. 보조 계열은 여전히 공급 입력만 사용.',
        '- 혼합 목표: 4계열 8개 시점, 1,000개 경로, 두 seed. 거시 중첩 점검은 45개 시점, 1,000개 경로, 두 seed.',
        '- 기본 관측 스텝은 일별 [5,21,63]·월별 [1,3,9], 기간 변경은 [5,21]·[1,3,6]. 인공 관측 스텝 비교이지 봉인된 카드 target_date의 재현이 아니다.',
        '- 같은 시점의 두 seed를 먼저 평균했다. 다른 seed, horizon, 겹치는 기간을 독립 표본으로 세지 않았다.',
        '- 2020–2024년은 이전 연구에서도 봤던 자료다. 후보 수가 많고 표본·연도 수가 적어 탐색적 연도 블록 구간은 확정적 유의성 근거가 아니다.',
        '- 거시는 한 개 수정 빈티지이며 실제 최초 발표 당시 검증이 아니다. 새로운 나라·빈도·누락 패턴까지 정확도를 일반화하지 않는다.',
        '- 현재 사용 가능한 공급 파일에는 GDP 이력이 없었다. CNY·INR·BRL은 초기 transfer 이력만 있어 후속 정확도를 검증하지 못했고 기존 안전한 proxy 경로를 유지했다.',
        '- 실제 House 응답의 정확도·텍스트 효과, 공식 M0 정규화와 Codabench 점수는 미검증이다.','',
        '## 실행·재현','',
        f'최종 연구 이미지에서 신규·기존 코드 검사 **{qa_count}/{qa_count}**, 두 연구 옵션 각각 공개 과제 공식 출력 게이트 **103/103**, '+
        '네 과제 유형 모의 House 처리 통과. 두 옵션 각각 네트워크 차단·읽기 전용 실제 forecast 실행 **4/4** 통과, '+
        '출력은 정확히 forecast.parquet/forecast_meta.json/forecast_rationale.md 세 파일이다. '+
        '게이트 통과는 정확도 또는 규칙 전체 승인이라는 뜻이 아니다. 공식 도구 전체 suite 전부 통과라고 주장하지 않는다.','',
        f'실행 검증 중 Docker/WSL 환경이 중단되어 재시작했다. 같은 최종 이미지에서 완료 출력 '+
        f'expert {gates["expert"]["reused_and_regated"]}개·fast_price {gates["fast"]["reused_and_regated"]}개는 복사 후 공식 게이트를 다시 검사하고, '+
        '나머지와 모든 모의 House 실행은 새로 생성했다. 재사용은 예측 코드나 수치 실험을 바꾸지 않는다.','',
        '개발 단계의 두 구현 오류(월간 회귀 절편·FX 인용 방향)와 단일 목표 날짜의 grain 문제를 수정하고 회귀 검사를 추가했다. '+
        '수치 core는 후속 평가 전에 고정했다. 이후 추가한 혼합 dispatcher와 연구용 cache·중첩 평가의 범위는 INTEGRATION_SCOPE.md에 기록했다.','',
        'ZIP에는 VExpert 소스, 제출 수치 baseline 소스, 28계열 결과 CSV, 모든 집계 표, 검증 기록, 재현 코드와 해시를 담았다. '+
        '원시 패널·사건별 손실·개별 예측·정답·팀 인증 파일은 제외했다. '+
        'research/REPRODUCE.ps1 -RepositoryRoot <V11/units가 있는 저장소>로 재현한다. 기존 결과는 덮어쓰지 않는다.','',
        '## 현재 판단','',
        '**계열별 모델 설계와 통합 검증을 수행했고, fast_price는 수치 실험에서 더 유망한 추가 조합이다. '+
        '다만 선택에 사용한 기간을 다시 측정한 것이므로 전체 대회 우월성이나 독립 검증 완료를 주장하지 않는다.** '+
        '제출된 VSpecial은 그대로 유지한다. 다음 제출 후보를 검토할 때 fast_price를 비교 대상으로 둘 수 있지만 '+
        '실제 House와 M0/봉인된 평가 결과를 확인해야 한다. 개발 최고 후보를 전 계열에 무조건 붙이는 방식은 채택하지 않는다.','',
        '모델 이론의 참고 자료와 공식 규칙 링크는 research/PROTOCOL.md 및 ARTIFACT_PROVENANCE.md에 있다. '+
        '데이터 검증 과정에서 기간·목표 범위를 나눠 계산했고, 독립 CSV 재계산으로 아래 집계와 결과표의 산술 일치를 확인했다.','']
    (OUT/'SUMMARY_KR.md').write_text('\n'.join(lines),encoding='utf8')
    verification={'independent_checks':checks,'assets':28,'expert_settings':len(configs),
        'asset_candidate_pairs':sum(r['candidate_settings_tested'] for r in decisions),'not_official_score':True,
        'code_tests_passed':qa_count,'validation_modes':gates,
        'model_core_sha256':'3f64a448d5ccf6ccd03210fcd34acfc7611b34b16d37c8160bf9a1078d27bc84'}
    (OUT/'ANALYSIS_VERIFICATION.json').write_text(json.dumps(verification,indent=2))
    print(json.dumps(verification))
    print(json.dumps([r for r in decisions if r['asset'] in ['BAB','HML','NFP','UNRATE','CPI_ALL','CPI_CORE','PCE_ALL','PCE_CORE']],ensure_ascii=False,indent=2))

if __name__=='__main__':main()
