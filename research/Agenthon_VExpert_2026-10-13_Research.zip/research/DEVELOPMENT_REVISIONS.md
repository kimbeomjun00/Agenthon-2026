## Executive summary (read this first)

Before any subsequent-period scoring, development/code review exposed two model
specification defects. Correct them, add regression tests, and rerun affected development
panels. No candidate was revised after inspecting its 2020-2024 performance.

1. The demeaned monthly ridge fit omitted its fitted growth intercept when forecasting.
   Daily drift-prior constraints were unintentionally reused for monthly trending levels.
   Restore the monthly intercept. A deterministic growing-price test must forecast growth.
2. The DKK/EUR spread assumed identical quote directions. Historical panels may quote
   one currency reciprocally. Estimate the return hedge ratio from supplied past data and
   form the corresponding spread; do not use a stored parity or historical event date.
   A synthetic inverse-quote test must retain a nearly constant DKK*EUR product.

Initial development runs are retained as dev_macro/dev_fx diagnostics. Corrected results
are dev2_macro/dev2_fx. Rates/factors formulas are unchanged; their first development
run hashes differ because the same module also contains the corrected macro/FX branches.
The initial pilot runs precede the added factor-role candidate and are not final results.

3. Before target-only evaluation, coverage inspection found extra BAB/QMJ dates relative
   to other factor covariates. Resolved-fold outcomes and single-target backtest windows
   must follow the target set's own observed rows, not the covariates' complete-case rows.
   Add a missing-covariate-date regression test. Joint-panel development results are
   unchanged: their target-set rows equal the joint context rows. This remains an artificial
   observation-step backtest, not a reconstruction of sealed authored-card target dates.
