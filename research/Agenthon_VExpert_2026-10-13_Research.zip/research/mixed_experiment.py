"""## Executive summary (read this first)
Test the rate/FX integration on artificial common-observation cutoffs, not sealed cards.
Record losses and sanitized provenance only. Pure-panel experts remain frozen.
"""
import argparse,hashlib,importlib,importlib.util,json,pathlib,sys,time
import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from qfbench2_track_forecasting.cli import _draw
from vnext.portfolio import forecast
from vnext.inflation import forecast as safe
from vnext.specialists import prepare,_scale
spec=importlib.util.spec_from_file_location('submitted_vnext','/baseline/vnext/__init__.py',submodule_search_locations=['/baseline/vnext'])
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
submitted=importlib.import_module('submitted_vnext.inflation').forecast
ls=importlib.util.spec_from_file_location('legacy_measure','/oldlab/experiment.py')
legacy=importlib.util.module_from_spec(ls);ls.loader.exec_module(legacy)

def run(args):
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    sources=legacy.sources(pathlib.Path('/repo/V11'));assets=['UST_2Y','UST_10Y','EUR','JPY'];panels={};source_hashes={}
    for group in ['rates','fx']:
        path,df,key=sources[group];panels[group]=df.rename(columns={key:'asset'})
        source_hashes[group]=hashlib.sha256(path.read_bytes()).hexdigest()
    df=pd.concat(list(panels.values()));wide=df[df['asset'].isin(assets)].pivot(index='date',columns='asset',values='value').reindex(columns=assets).dropna()
    hs=np.array([5,21,63]);steps=np.tile(hs,(4,1));indices=[]
    eligible=np.flatnonzero((wide.index.year>=2020)&(wide.index.year<=2024)&(np.arange(len(wide))+63<len(wide)))
    for ix in eligible:
        if not indices or ix-indices[-1]>=63:indices.append(int(ix))
    if len(indices)>args.count:indices=[indices[i] for i in np.unique(np.linspace(0,len(indices)-1,args.count).round().astype(int))]
    rows=[];joint=[];selections=[];start=time.monotonic()
    for case,ix in enumerate(indices):
        cutoff=wide.index[ix];asof=str(cutoff.date());past={k:f[f['date']<=cutoff].copy() for k,f in panels.items()}
        state=prepare(past,assets,asof,'level',False);truth=wide.iloc[ix+hs].to_numpy(float)
        scale=np.maximum(_scale(state.x)*np.sqrt(hs[:,None]),1e-8)
        baseline,_=submitted(past,assets,steps,asof,'level',args.draws,args.seed)
        control,_=safe(past,assets,steps,asof,'level',args.draws,args.seed)
        integrated,meta=forecast(past,assets,steps,asof,'level',args.draws,args.seed)
        selections.append({'asof':asof,'targets':assets,'metadata':meta})
        reference,_=_draw(past,assets,hs.tolist(),asof,args.draws,args.seed+191,target_type='level')
        ref=reference.transpose(0,2,1);rs=legacy.expectation_scale(ref,args.seed)
        ars=[legacy.expectation_scale(ref[:,:,i:i+1],args.seed) for i in range(4)]
        for mode,sample in [('submitted',baseline),('safe',control),('integrated',integrated)]:
            scores=legacy.composite(sample,truth);crps=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
            low,high=np.quantile(sample,[.05,.95],axis=0)
            row={'case':case,'panel':'mixed','asof':asof,'model':mode,'seed':args.seed,'draws':args.draws,
                 'profile':'mixed_rate_fx','target_set':','.join(assets),'crps_scaled':float(np.mean(crps/scale)),
                 'local_composite':sum(w*scores[k]/rs[k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                 'coverage90':float(np.mean((truth>=low)&(truth<=high)))}
            joint.append(row|{k:scores[k] for k in ('marginal','joint','tail')})
            for ai,a in enumerate(assets):
                per=legacy.composite(sample[:,:,ai:ai+1],truth[:,ai:ai+1])
                rows.append(row|{'asset':a,'crps_scaled':float(np.mean(crps[:,ai]/scale[:,ai])),
                    'coverage90':float(np.mean((truth[:,ai]>=low[:,ai])&(truth[:,ai]<=high[:,ai]))),
                    'local_composite':sum(w*per[k]/ars[ai][k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                    **{k:per[k] for k in ('marginal','joint','tail')}})
        pd.DataFrame(rows).to_csv(out/'asset_metrics.csv',index=False);pd.DataFrame(joint).to_csv(out/'joint_metrics.csv',index=False)
        print('mixed',case+1,len(indices),asof,f'{time.monotonic()-start:.1f}s',flush=True)
    pd.DataFrame(rows).groupby(['panel','asset','model']).mean(numeric_only=True).reset_index().to_csv(out/'asset_summary.csv',index=False)
    pd.DataFrame(joint).groupby(['panel','target_set','model']).mean(numeric_only=True).reset_index().to_csv(out/'joint_summary.csv',index=False)
    (out/'selections.json').write_text(json.dumps(selections,indent=2))
    (out/'run.json').write_text(json.dumps(vars(args)|{'panel':'mixed','cases':len(indices),'assets':assets,
        'source_sha256':source_hashes,'seconds':time.monotonic()-start,
        'model_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/opt/vnext').glob('*.py')},
        'label':'exploratory mixed-domain comparison; no Codabench score'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=42);p.add_argument('--count',type=int,default=8)
    p.add_argument('--draws',type=int,default=1000);p.add_argument('--out',required=True);run(p.parse_args())
