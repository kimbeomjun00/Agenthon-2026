## Executive summary (read this first)

All 28-series candidate and integration experiments were completed first. They exposed
weakness in past-fold selection despite useful individual price filters. Add a clearly
post-comparison research composition: all four price indices use the already frozen fast
native-growth Kalman filter; daily series retain the evaluated domain portfolio router;
NFP/UNRATE retain VSpecial. No hardcoded benchmark losses, unit IDs, event dates or fitted
regression parameters are deployed. States/variance always fit the current unit history.

The family choice was made AFTER looking at primary/sensitivity/dense results. Its new
composition tests reuse those periods and cannot establish independent confirmation.
Retain this caveat beside every gain; do not overwrite the previous integrated results.
Default CLI remains expert. fast_price is an additional research option, not a submission.

Price trajectories are terminal-rank aligned to the current baseline's joint paths and
share 20% original-baseline insurance. This does not prove exact covariance preservation.
Evaluate joint/tail losses separately and test nonprice macro identity and cutoff invariance.
