"""## Executive summary (read this first)
Run the repaired default forecast in offline, read-only containers, one unit per family.
"""
import argparse,json,pathlib,subprocess,time,tomllib
base=pathlib.Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser();ap.add_argument('--repository-root',type=pathlib.Path,default=base/'agenthon-v11-work')
ap.add_argument('--out',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent/'results'/'container_final')
ap.add_argument('--image',default='agenthon-vexpert:research')
ap.add_argument('--mode',choices=['expert','fast_price'])
args=ap.parse_args();units=args.repository_root.resolve()/'V11'/'units'
out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
code='''import json,pathlib
from qfbench2_track_forecasting.scoring import GATES,hydrate_ctx
ctx={"unit_dir":pathlib.Path("/input"),"output_dir":pathlib.Path("/output"),"realized":None}
hydrate_ctx(ctx);g={name:gate(ctx).passed for name,gate in GATES}
print(json.dumps(g));raise SystemExit(0 if all(g.values()) else 1)
'''
rows=[]
for name in ['t2-F1-ai-mom-2024','t2-F2-cnh-stress-2015','t2-F3-bear-flattener-2022','t2-F4-cpi-vintage-2022']:
    unit=units/name;card=tomllib.loads((unit/'card.toml').read_text(encoding='utf8'));dest=out/'outputs'/name;dest.mkdir(parents=True)
    cmd=['docker','run','--rm','--network=none','--read-only','--tmpfs','/tmp:rw,noexec,nosuid,size=512m',
         '--cpus=4','--memory=4g','--mount',f'type=bind,source={unit},target=/input,readonly',
         '--mount',f'type=bind,source={dest},target=/output',args.image]
    t=time.monotonic()
    forecast_args=['forecast','--panels','/input/panels','--text','/input/text','--asof',str(card['provenance']['data_cutoff']),
                   '--out','/output/forecast.parquet']
    if args.mode:forecast_args+=['--mode',args.mode]
    run=subprocess.run(cmd+forecast_args,capture_output=True,text=True)
    gate=subprocess.run(cmd+['python3','-c',code],capture_output=True,text=True) if run.returncode==0 else None
    rows.append({'unit':name,'forecast_exit':run.returncode,'gate_exit':gate.returncode if gate else None,
                 'mode':args.mode or 'image_default','image':args.image,
                 'gates':json.loads(gate.stdout) if gate and gate.returncode==0 else {},
                 'files':sorted(p.name for p in dest.iterdir()),'seconds':time.monotonic()-t,'stdout':run.stdout,'stderr':run.stderr})
    (out/'result.json').write_text(json.dumps(rows,indent=2));print(name,run.returncode,gate.returncode if gate else None,flush=True)
    if run.returncode or not gate or gate.returncode:raise SystemExit(1)
