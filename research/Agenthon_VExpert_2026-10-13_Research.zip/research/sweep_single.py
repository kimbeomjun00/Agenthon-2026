"""## Executive summary (read this first)
Run both seeds of single-target checks; macro also gets a clearly overlapping monthly sweep.
No model settings change between phases. All existing result folders are preserved.
"""
import argparse
from experiment import run
p=argparse.ArgumentParser();p.add_argument('--panel',required=True);args=p.parse_args()
for seed in [42,77]:
    run(argparse.Namespace(panel=args.panel,split='evaluation',draws=1000,seed=seed,count=8,
        horizons='',assets='',single_all=True,stride=0,out=f'/lab/results/single{seed}_{args.panel}'))
if args.panel=='macro':
    for seed in [42,77]:
        run(argparse.Namespace(panel='macro',split='evaluation',draws=1000,seed=seed,count=0,
            horizons='',assets='',single_all=False,stride=1,out=f'/lab/results/dense{seed}_macro'))
