## Executive summary (read this first)

No numerical experiment or model formula was changed during validation recovery.

- Docker/WSL stopped unexpectedly during two final-image gate runs. The host log
  showed a WSL version-query/installer registration error. Memory exhaustion is NOT
  established. A Docker Desktop restart restored the existing engine and images;
  no data reset, WSL unregister, OS install or registry push was performed.
- Fresh recovery result directories preserve both interrupted runs. Only outputs
  already marked successful from the same immutable image are eligible for reuse.
  Official gates are rerun before and after copying; missing units and all four mock
  House examples are generated anew. Each final summary records the reuse count.
- The first optional-mode read-only smoke helper used a relative Windows output path.
  Docker rejected the mount before any forecast ran. The helper now resolves absolute
  paths; a fresh output directory is used for the successful rerun.
- A QA invocation omitted /repo, so the fixture-dependent House-anchor test could
  not load card.toml (43 passed, 1 missing-file failure). The corrected invocation
  mounts the unchanged repository read-only. qa_final.xml, not that failed invocation,
  is the final packaged QA evidence. REPRODUCE.ps1 already includes this mount.

These invocation/environment failures are not hidden as successful tests. Raw prior
outputs remain local; the handoff includes completed final validation aggregates only.
