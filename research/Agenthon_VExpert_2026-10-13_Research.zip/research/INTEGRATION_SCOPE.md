## Executive summary (read this first)

The public cards include mixed rate/FX targets. Add a separate cross-domain dispatcher
instead of allowing a currency to enter a Nelson-Siegel yield-curve fit. The frozen
experts.py numerical core remains unchanged. All pure-panel comparisons are unchanged.

portfolio.py calls the rate/FX experts separately, then aligns whole asset trajectories
to the original cross-domain joint baseline's terminal ranks. Nested horizon paths and
per-asset marginal samples survive the permutation. Shared original baseline insurance
and a resolved-past joint-loss gate constrain the integration. This is approximate copula
coupling, not a claim of exact covariance preservation or verified future superiority.

This structural component was added after pure-panel evaluation started, before any
mixed-profile scoring. Its choices use actual card target schemas, not mixed future losses.
Test mixed UST_2Y, UST_10Y, EUR, JPY on common supplied observation rows. Treat that profile
as exploratory too, and do not silently combine it with the per-panel averages.

GDP has no supplied history. CNY/INR/BRL cards have early transfer histories rather than
complete subsequent observations. Keep the existing safe proxy-transfer path and report
their accuracy as unverified, not as covered by the 28-series numerical result table.

Additional verification, with no model-core change: single-target simulations use a
per-origin, input-hashed in-memory cache whose numerical equivalence was tested across
all four families. Macro also uses monthly overlapping origins, reported separately from
the five nonoverlapping primary origins. More overlapping origins are not more independent
events. Exact research-script revisions are recorded by run and package manifests.
