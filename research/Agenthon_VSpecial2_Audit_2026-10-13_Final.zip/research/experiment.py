"""## Executive summary (read this first)
Compare audited candidates with byte-verified submitted VSpecial source on artificial cutoffs.
Save losses, not individual forecast values or hidden-card answers.
"""
import argparse,hashlib,importlib,importlib.util,json,pathlib,sys,time,warnings
import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from qfbench2_track_forecasting.cli import _draw
from vnext.inflation import forecast as fixed
from vnext.refinements import forecast as refined
from vnext.specialists import prepare,_scale
from vnext.geometric import forecast as geometric
sys.path.insert(0,'/oldlab')
from experiment import sources,composite,expectation_scale
sys.path.pop(0)

spec=importlib.util.spec_from_file_location('submitted_vnext','/baseline/vnext/__init__.py',
                                          submodule_search_locations=['/baseline/vnext'])
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
submitted=importlib.import_module('submitted_vnext.inflation').forecast
warnings.filterwarnings('ignore',category=UserWarning)

def run(args):
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    src=sources(pathlib.Path('/repo/V11'));path,df,acol=src[args.panel]
    assets=args.assets.split(',') if args.assets else sorted(df[acol].unique().tolist());monthly=args.panel=='macro'
    target='log_return' if args.panel=='factors' else 'level'
    hs=np.array(list(map(int,args.horizons.split(',')))) if args.horizons else np.array([1,3,9] if monthly else [5,21,63])
    wide=df[df[acol].isin(assets)].pivot(index='date',columns=acol,values='value').reindex(columns=assets).dropna()
    maximum=int(hs.max());minimum=84 if monthly else 750
    lo,hi=(2006,2019) if args.split=='development' else (2020,2024)
    eligible=np.flatnonzero((wide.index.year>=lo)&(wide.index.year<=hi)&(np.arange(len(wide))>=minimum)&(np.arange(len(wide))+maximum<len(wide)))
    indices=[]
    for ix in eligible:
        if not indices or ix-indices[-1]>=maximum:indices.append(int(ix))
    if args.count and len(indices)>args.count:
        indices=[indices[i] for i in np.unique(np.linspace(0,len(indices)-1,args.count).round().astype(int))]
    models=['submitted','fixed','cpi_soft'] if args.cpi_only else (['submitted','fixed','geometric'] if args.geometric_only else (['submitted','fixed','soft','calibrated'] if monthly else ['submitted','fixed','term','daily_calibrated']))
    rows=[];joint=[];selections=[];t=time.monotonic()
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/opt/vnext').glob('*.py')}
    for case,ix in enumerate(indices):
        cutoff=wide.index[ix];asof=str(cutoff.date());panels={args.panel:df[df['date']<=cutoff].copy()}
        future=wide.iloc[ix+1:ix+maximum+1].to_numpy(float)
        truth=np.stack([np.log1p(future[:h]).sum(axis=0) if target=='log_return' else future[h-1] for h in hs])
        steps=np.tile(hs,(len(assets),1));s=prepare(panels,assets,asof,target,monthly)
        scale=np.maximum(_scale(s.x)*np.sqrt(hs[:,None]),1e-8)
        raw,_=_draw(panels,assets,hs.tolist(),asof,args.draws,args.seed+191,target_type=target,panel_steps=steps if monthly else None)
        reference=raw.transpose(0,2,1);rs=expectation_scale(reference,args.seed)
        ars=[expectation_scale(reference[:,:,i:i+1],args.seed) for i in range(len(assets))]
        for mode in models:
            if mode=='submitted':sample,meta=submitted(panels,assets,steps,asof,target,args.draws,args.seed,monthly)
            elif mode=='fixed':sample,meta=fixed(panels,assets,steps,asof,target,args.draws,args.seed,monthly)
            elif mode=='geometric':sample,meta=geometric(panels,assets,steps,asof,target,args.draws,args.seed,monthly)
            else:sample,meta=refined(panels,assets,steps,asof,target,args.draws,args.seed,monthly,mode)
            selections.append({'asof':asof,'model':mode,'metadata':meta})
            scores=composite(sample,truth);crps=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
            low,high=np.quantile(sample,[.05,.95],axis=0)
            row={'case':case,'panel':args.panel,'asof':asof,'model':mode,'seed':args.seed,
                 'draws':args.draws,'crps_scaled':float(np.mean(crps/scale)),
                 'local_composite':sum(w*scores[k]/rs[k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                 'coverage90':float(np.mean((truth>=low)&(truth<=high)))}
            joint.append(row|{k:scores[k] for k in ('marginal','joint','tail')})
            for ai,a in enumerate(assets):
                per=composite(sample[:,:,ai:ai+1],truth[:,ai:ai+1])
                rows.append(row|{'asset':a,'crps_scaled':float(np.mean(crps[:,ai]/scale[:,ai])),
                    'coverage90':float(np.mean((truth[:,ai]>=low[:,ai])&(truth[:,ai]<=high[:,ai]))),
                    'local_composite':sum(w*per[k]/ars[ai][k] for w,k in zip((.5,.3,.2),('marginal','joint','tail'))),
                    **{k:per[k] for k in ('marginal','joint','tail')}})
        pd.DataFrame(rows).to_csv(out/'asset_metrics.csv',index=False)
        pd.DataFrame(joint).to_csv(out/'joint_metrics.csv',index=False)
        print(args.panel,args.split,case+1,len(indices),asof,f'{time.monotonic()-t:.1f}s',flush=True)
    a=pd.DataFrame(rows);j=pd.DataFrame(joint)
    a.groupby(['panel','asset','model']).mean(numeric_only=True).reset_index().to_csv(out/'asset_summary.csv',index=False)
    j.groupby(['panel','model']).mean(numeric_only=True).reset_index().to_csv(out/'joint_summary.csv',index=False)
    (out/'selections.json').write_text(json.dumps(selections,indent=2))
    (out/'run.json').write_text(json.dumps(vars(args)|{'cases':len(indices),'assets':assets,'model_hashes':hashes,
        'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seconds':time.monotonic()-t,
        'label':'exploratory numeric backtest, not Codabench; macro single revised vintage'},indent=2))
    print(j.groupby('model')[['crps_scaled','local_composite','coverage90']].mean().to_string(),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--panel',required=True,choices=['rates','fx','factors','macro'])
    ap.add_argument('--split',default='development',choices=['development','evaluation']);ap.add_argument('--draws',type=int,default=1000)
    ap.add_argument('--seed',type=int,default=42);ap.add_argument('--count',type=int,default=0)
    ap.add_argument('--horizons',default='');ap.add_argument('--assets',default='');ap.add_argument('--out',required=True)
    ap.add_argument('--geometric-only',action='store_true');ap.add_argument('--cpi-only',action='store_true');run(ap.parse_args())
