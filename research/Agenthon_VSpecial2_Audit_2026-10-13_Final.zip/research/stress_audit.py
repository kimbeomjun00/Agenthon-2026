"""## Executive summary (read this first)
Record sanitized boundary-case evidence against original VSpecial and the repaired model.
Synthetic histories only; no team claim or submission descriptor is read or copied.
"""
import importlib,importlib.util,json,pathlib,sys
import numpy as np
import pandas as pd
from vnext.inflation import forecast as repaired
from vnext.specialists import prepare

spec=importlib.util.spec_from_file_location('submitted_vnext','/baseline/vnext/__init__.py',submodule_search_locations=['/baseline/vnext'])
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
original=importlib.import_module('submitted_vnext.inflation').forecast

def panel(dates,values,assets):
    return {'p':pd.DataFrame({'date':np.repeat(dates,len(assets)),'asset':np.tile(assets,len(dates)),
                             'value':np.asarray(values).reshape(-1)})}

def main():
    out=pathlib.Path('/lab/results/stress_audit');out.mkdir(parents=True,exist_ok=False)
    dates=pd.bdate_range('2000-01-03',periods=1800);x=2+np.cumsum(np.random.default_rng(5).normal(0,.01,1800));x[800:]+=100
    keep=np.r_[np.arange(500),np.arange(800,1800)];p=panel(dates[keep],x[keep,None],['UST_10Y'])
    results={}
    for name,fn in [('submitted',original),('repaired',repaired)]:
        sample,_=fn(p,['UST_10Y'],np.array([[21,63]]),str(dates[-1].date()),'level',2000,42)
        results[name]={'sd_at_63':float(sample[:,1,0].std()),'mean_error_vs_current_anchor':float(sample[:,1,0].mean()-x[-1])}
    dates=pd.date_range('2000-01-01',periods=220,freq='MS');values=100+np.cumsum(np.random.default_rng(4).normal(.25,.03,(220,2)),axis=0)
    p=panel(dates,values,['CPI_ALL','CPI_CORE']);p['p'].loc[p['p']['asset']=='CPI_CORE','date']+=pd.Timedelta(days=14)
    for name,fn in [('submitted',original),('repaired',repaired)]:
        try:
            sample,_=fn(p,['CPI_ALL','CPI_CORE'],np.tile([1,3,9],(2,1)),'2018-04-30','level',512,42,True)
            results[name]['different_month_days_ok']=bool(np.isfinite(sample).all())
        except ValueError as e:results[name].update(different_month_days_ok=False,error=str(e))
    (out/'result.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
