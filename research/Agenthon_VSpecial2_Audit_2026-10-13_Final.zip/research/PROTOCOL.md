## Executive summary (read this first)

Compare follow-up candidates with the submitted immutable VSpecial before seeing its score.
Do not modify the submitted ZIP, image digest, team claim, or Codabench entry.

Baseline: docker.io/kbj710211/agenthon-t2-v11@sha256:68d85e885da895a9559996675a44f5bbae289538dd03be1ecc0f97e959d6e821.
Its vnext and v11_new source hashes match the previous VSpecial package.

1. Audit valid irregular input cases and House numerical context on the submitted image.
2. Follow-up numerical candidates: hard winner (control), soft inflation mixture, calibrated
   inflation mixture, daily volatility-term structure, cutoff-local daily scale/mean selection.
3. Development 2006-2019 fixes design choices; 2020-2024 is an exploratory subsequent period
   already used in previous studies. Do not call it a pristine holdout.
4. Primary monthly grid [1,3,9], daily grid [5,21,63]; non-overlapping outcome windows within each
   grid. Follow-up sensitivity uses [1,3,6] monthly and [5,21] daily. Across grids events may overlap.
5. 1,000 draws on development; 2,000 draws with seeds 42/77 on evaluation. Seeds are repetitions,
   not independent events. Report per-asset CRPS, joint, tail and interval coverage.
6. Import the canonical scoring functions. Any input-scaled selector objective/local composite
   is a surrogate, not organizer M0 normalization or a Codabench score.
7. The House context fix is tested for truthful inputs and output gates. No actual House accuracy
   or text uplift is claimed without a real endpoint. Mock responses are plumbing tests only.
8. Macro uses one revised vintage. Synthetic gap cases are robustness tests, not actual EM outcomes.
9. Publish only research source, aggregate loss tables and sanitized audit metadata. Do not publish
   submission team-claim files, credentials, raw panels, individual forecasts or answer tables.
