"""## Executive summary (read this first)
Pair candidate losses with the submitted VSpecial, averaging seeds per event.
Report exploratory year-block intervals and raw joint/tail diagnostics.
"""
import argparse,json,pathlib
import numpy as np
import pandas as pd

def main(args):
    root=pathlib.Path(args.root);out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True)
    dirs=[p for pattern in args.patterns.split(',') for p in root.glob(pattern) if (p/'asset_metrics.csv').is_file()]
    a=pd.concat([pd.read_csv(p/'asset_metrics.csv') for p in dirs],ignore_index=True)
    j=pd.concat([pd.read_csv(p/'joint_metrics.csv') for p in dirs],ignore_index=True)
    a=a.groupby(['panel','asset','asof','model']).mean(numeric_only=True).reset_index()
    j=j.groupby(['panel','asof','model']).mean(numeric_only=True).reset_index()
    columns=['crps_scaled','local_composite','marginal','joint','tail','coverage90']
    am=a.groupby(['panel','asset','model'])[columns].mean().reset_index();jm=j.groupby(['panel','model'])[columns].mean().reset_index()
    b=am[am['model']=='submitted'].set_index(['panel','asset']);jb=jm[jm['model']=='submitted'].set_index('panel')
    for metric in columns[:-1]:
        am['gain_'+metric]=[1-r[metric]/b.loc[(r['panel'],r['asset']),metric] for _,r in am.iterrows()]
        jm['gain_'+metric]=[1-r[metric]/jb.loc[r['panel'],metric] for _,r in jm.iterrows()]
    am.to_csv(out/'asset_summary.csv',index=False);jm.to_csv(out/'panel_summary.csv',index=False)
    uncertainty=[]
    for (panel,asset),grp in a.groupby(['panel','asset']):
        pivot=grp.pivot(index='asof',columns='model',values='crps_scaled');years=pd.to_datetime(pivot.index).year
        blocks=sorted(set(years));draw=np.random.default_rng(732).integers(len(blocks),size=(3000,len(blocks)))
        for model in pivot.columns:
            if model=='submitted':continue
            totals=np.array([[pivot.loc[years==year,model].sum(),pivot.loc[years==year,'submitted'].sum()] for year in blocks])
            sums=totals[draw].sum(axis=1);boot=1-sums[:,0]/sums[:,1];lo,hi=np.quantile(boot,[.025,.975])
            uncertainty.append({'panel':panel,'asset':asset,'model':model,'cases':len(pivot),'year_blocks':len(blocks),
                'gain':1-pivot[model].mean()/pivot['submitted'].mean(),'ci_low':lo,'ci_high':hi,
                'win_rate':float(np.mean(pivot[model]<pivot['submitted']))})
    pd.DataFrame(uncertainty).to_csv(out/'uncertainty.csv',index=False)
    (out/'analysis.json').write_text(json.dumps({'runs':list(map(str,dirs)),
        'cases_per_panel':a.groupby('panel')['asof'].nunique().to_dict(),
        'meaning':'exploratory, seed-averaged events; year-block bootstrap with few years, not a formal selection-adjusted confidence claim'},indent=2))
    print(jm[['panel','model','gain_crps_scaled','gain_local_composite','coverage90']].to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='audit-lab/results');p.add_argument('--patterns',default='eval*')
    p.add_argument('--out',required=True);main(p.parse_args())
