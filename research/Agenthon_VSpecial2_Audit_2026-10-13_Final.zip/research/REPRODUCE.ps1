# ## Executive summary (read this first)
# Reproduce the audit and comparisons without changing any submitted artifact.
param([Parameter(Mandatory=$true)][string]$RepositoryRoot)
$ErrorActionPreference='Stop'
$bundleRoot=Split-Path -Parent $PSScriptRoot
$repoResolved=(Resolve-Path -LiteralPath $RepositoryRoot).Path
$researchResolved=(Resolve-Path -LiteralPath $PSScriptRoot).Path
$baselineResolved=(Resolve-Path -LiteralPath (Join-Path $bundleRoot 'VSpecial_baseline')).Path
$legacyResolved=(Resolve-Path -LiteralPath (Join-Path $researchResolved 'legacy')).Path
$testsResolved=(Resolve-Path -LiteralPath (Join-Path $bundleRoot 'VSpecial2/tests')).Path
if (!(Test-Path -LiteralPath (Join-Path $repoResolved 'V11/units'))) { throw 'RepositoryRoot must contain V11/units' }
docker build -t agenthon-vspecial2:research (Join-Path $bundleRoot 'VSpecial2')
if ($LASTEXITCODE -ne 0) { throw 'Docker build failed' }
# Audit tests require the public practice-unit mount; no House endpoint is called.
docker run --rm --network none --cpus=4 --memory=4g -e OPENBLAS_NUM_THREADS=1 `
  --mount "type=bind,source=$repoResolved,target=/repo,readonly" `
  --mount "type=bind,source=$researchResolved,target=/lab" `
  --mount "type=bind,source=$testsResolved,target=/tests,readonly" `
  agenthon-vspecial2:research python -m pytest /tests /lab/test_audit_cases.py /lab/test_refinements.py /lab/test_geometric.py -q
if ($LASTEXITCODE -ne 0) { throw 'Audit tests failed' }
foreach ($panel in @('rates','fx','factors','macro')) {
  foreach ($seed in @(42,77)) {
    docker run --rm --network none --cpus=4 --memory=4g -e OPENBLAS_NUM_THREADS=1 `
      --mount "type=bind,source=$repoResolved,target=/repo,readonly" `
      --mount "type=bind,source=$researchResolved,target=/lab" `
      --mount "type=bind,source=$baselineResolved,target=/baseline,readonly" `
      --mount "type=bind,source=$legacyResolved,target=/oldlab,readonly" `
      agenthon-vspecial2:research python /lab/experiment.py --panel $panel --split evaluation `
      --draws 2000 --seed $seed --out "/lab/results/repro$seed-$panel"
    if ($LASTEXITCODE -ne 0) { throw "Experiment failed: $panel seed $seed" }
  }
}
# Targeted follow-ups: primary CPI single/pair, alternate monthly grid, geometric.
foreach ($seed in @(42,77)) {
  foreach ($profile in @('cpi_single','cpi_pair','cpi_sens','geo')) {
    $extra=@('--cpi-only','--assets','CPI_ALL,CPI_CORE')
    if ($profile -eq 'cpi_single') { $extra=@('--cpi-only','--assets','CPI_ALL') }
    if ($profile -eq 'cpi_sens') { $extra+=@('--horizons','1,3,6') }
    if ($profile -eq 'geo') { $extra=@('--geometric-only') }
    docker run --rm --network none --cpus=4 --memory=4g -e OPENBLAS_NUM_THREADS=1 `
      --mount "type=bind,source=$repoResolved,target=/repo,readonly" `
      --mount "type=bind,source=$researchResolved,target=/lab" `
      --mount "type=bind,source=$baselineResolved,target=/baseline,readonly" `
      --mount "type=bind,source=$legacyResolved,target=/oldlab,readonly" `
      agenthon-vspecial2:research python /lab/experiment.py --panel macro --split evaluation `
      --draws 2000 --seed $seed --out "/lab/results/repro$seed-$profile" @extra
    if ($LASTEXITCODE -ne 0) { throw "Experiment failed: $profile seed $seed" }
  }
}
# Host Python with pandas/numpy can seed-average losses via research/analyze.py.
# Use --patterns 'repro*-cpi_single', 'repro*-cpi_pair', 'repro*-cpi_sens', or 'repro*-geo'
# separately; do not merge different asset subsets/horizon grids into one profile.
# Run directories are immutable; use a fresh output name for additional runs.
