"""## Executive summary (read this first)
Check the actual forecast verb in read-only, offline containers and run all official gates.
This host script uses Docker only; it does not need the evaluation toolkit on Windows.
"""
import json
import pathlib
import subprocess
import time
import tomllib

base=pathlib.Path(__file__).resolve().parent.parent
units=base/'agenthon-v11-work'/'V11'/'units'
out=base/'agenthon-lab'/'results'/'container_final_v2'
out.mkdir(parents=True,exist_ok=False)
cases=['t2-F1-ai-mom-2024','t2-F2-cnh-stress-2015','t2-F3-bear-flattener-2022','t2-F4-cpi-vintage-2022']
rows=[]
gate_code='''import json,pathlib
from qfbench2_track_forecasting.scoring import GATES,hydrate_ctx
ctx={"unit_dir":pathlib.Path("/input"),"output_dir":pathlib.Path("/output"),"realized":None}
hydrate_ctx(ctx)
r={name:gate(ctx).passed for name,gate in GATES}
print(json.dumps(r))
raise SystemExit(0 if all(r.values()) else 1)
'''
for name in cases:
    unit=units/name;cp=tomllib.loads((unit/'card.toml').read_text(encoding='utf8'))
    destination=out/'outputs'/name;destination.mkdir(parents=True)
    common=['docker','run','--rm','--network=none','--read-only','--tmpfs','/tmp:rw,noexec,nosuid,size=512m',
            '--cpus=4','--memory=8g','--mount',f'type=bind,source={unit},target=/input,readonly',
            '--mount',f'type=bind,source={destination},target=/output','agenthon-vnext:research']
    start=time.monotonic()
    args=common+['forecast','--panels','/input/panels','--text','/input/text','--asof',str(cp['provenance']['data_cutoff']),
                 '--out','/output/forecast.parquet']
    run=subprocess.run(args,text=True,capture_output=True)
    gate=subprocess.run(common+['python3','-c',gate_code],text=True,capture_output=True) if run.returncode==0 else None
    result={'unit':name,'forecast_exit':run.returncode,'gate_exit':gate.returncode if gate else None,
            'stdout':run.stdout,'stderr':run.stderr,'gates':json.loads(gate.stdout) if gate and gate.returncode==0 else {},
            'seconds':time.monotonic()-start,'files':sorted(p.name for p in destination.iterdir())}
    rows.append(result);print(name,result['forecast_exit'],result['gate_exit'],flush=True)
    (out/'result.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    if run.returncode!=0 or not gate or gate.returncode!=0:raise SystemExit(1)
print('Read-only offline forecast verb: 4/4 passed.')
