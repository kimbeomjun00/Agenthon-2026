"""## Executive summary (read this first)
Test missing-history transfer using synthetic five-year gaps on public G10 data.
These are invented tasks, not the competition's EM outcomes.
"""
import argparse
import json
import pathlib
import time
import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from vnext.numeric import forecast,prepare,_scale
from vnext.transfer import adjust
from v11_new.production_cli import _daily_e2_draws
from benchmark import data_sources


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='/lab/results/transfer01');args=ap.parse_args()
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    path,df,ac=data_sources(pathlib.Path('/repo/V11'))['fx']
    dates=np.sort(df['date'].unique());dates=pd.DatetimeIndex(dates)
    eligible=np.flatnonzero((dates.year>=2010)&(dates.year<=2019));eligible=eligible[eligible+63<len(dates)]
    origins=eligible[np.linspace(0,len(eligible)-1,12).round().astype(int)]
    rows=[];start=time.monotonic()
    for assets in (['EUR','JPY'],['AUD','CAD']):
        for ix in origins:
            asof=str(dates[ix].date());old_end=dates[ix]-pd.DateOffset(years=5)
            history=df[df['date']<=dates[ix]]
            keep=(~history[ac].isin(assets))|(history['date']<=old_end)|(history['date']==dates[ix])
            p={'fx':history[keep]};steps=np.tile([21,63],(len(assets),1))
            wide=df[df[ac].isin(assets)].pivot(index='date',columns=ac,values='value').reindex(columns=assets)
            truth=np.stack([wide.loc[dates[ix+h]].to_numpy(float) for h in [21,63]])
            hist=prepare(p,assets,asof,'level',absolute=True)
            scale=np.maximum(_scale(hist.steps.to_numpy())*np.sqrt(np.array([21,63])[:,None]),1e-8)
            safe,_=forecast(p,assets,steps,asof,'level',2000,42)
            transferred,meta=adjust(p,assets,steps,asof,safe,42)
            raw,*_=_daily_e2_draws(p,assets,[21,63],asof,'level',2000,42)
            for name,sample in [('v11',raw),('gap_safe_adaptive',safe),('proxy_mixture',transferred)]:
                loss=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
                rows.append({'asof':asof,'assets':'|'.join(assets),'model':name,
                             'crps_scaled':float(np.mean(loss/scale)),'proxy_applied':meta['applied']})
            print(f'{assets} {asof} done',flush=True)
    data=pd.DataFrame(rows);data.to_csv(out/'metrics.csv',index=False)
    summary=data.groupby('model')['crps_scaled'].mean();summary.to_csv(out/'summary.csv')
    (out/'run.json').write_text(json.dumps({'cases':24,'draws':2000,'seed':42,'seconds':time.monotonic()-start,
        'purpose':'synthetic gaps only; no claim about actual EM card accuracy'},indent=2))
    print(summary.to_string())
if __name__=='__main__':main()
