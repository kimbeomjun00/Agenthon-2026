"""## Executive summary (read this first)
Compare numeric methods on artificial historical cutoffs, without scoring authored units.
Evaluation values remain in memory. Output files contain losses and provenance only.
The House model is unavailable locally; this is a numeric ablation, not a leaderboard score.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib
import time
import tomllib
import warnings

import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from qfbench2_track_forecasting.scoring import _composite
from qfbench2_track_forecasting.cli import _draw
from v11_new.production_cli import _daily_e2_draws
from vnext.numeric import forecast,prepare,_scale

warnings.filterwarnings('ignore',category=UserWarning)
PANELS={
    'rates':('rates_daily.parquet',[['UST_2Y','UST_10Y'],['UST_2Y','UST_5Y','UST_10Y','UST_30Y']]),
    'fx':('g10_fx_daily.parquet',[['EUR','JPY','GBP','AUD'],['CHF','CAD','NZD','NOK']]),
    'factors':('factors_daily.parquet',[['MKT','SMB','HML'],['MOM','BAB','QMJ']]),
    'macro':('macro_monthly.parquet',[['CPI_ALL','CPI_CORE'],['NFP','UNRATE']]),
}


def data_sources(root: pathlib.Path) -> dict:
    sources={}
    for panel,(filename,_) in PANELS.items():
        paths=list((root/'units').glob('*/'+filename))
        path=max(paths,key=lambda p:p.stat().st_size)
        df=pd.read_parquet(path)
        col='asset' if 'asset' in df else 'asset_id'
        df['date']=pd.to_datetime(df['date'])
        sources[panel]=(path,df,col)
    return sources


def cases(root: pathlib.Path, split: str, count: int):
    for panel,(path,df,ac) in data_sources(root).items():
        for subset in PANELS[panel][1]:
            wide=df[df[ac].isin(subset)].pivot(index='date',columns=ac,values='value').reindex(columns=subset).dropna()
            hs=[2,6,9] if panel=='macro' else [5,21,63]
            m=max(hs)
            eligible=np.flatnonzero((wide.index.year>=2006)&(wide.index.year<=2019)) if split=='development' else np.flatnonzero(wide.index.year>=2020)
            eligible=eligible[(eligible>=120 if panel=='macro' else eligible>=500)&(eligible+m<len(wide))]
            if not len(eligible): continue
            indices=np.unique(eligible[np.linspace(0,len(eligible)-1,count).round().astype(int)])
            for ix in indices:
                cutoff=wide.index[ix]
                train=df[df['date']<=cutoff].copy()
                target_type='log_return' if panel=='factors' else 'level'
                future=wide.iloc[ix+1:ix+1+m].to_numpy(float)
                truth=np.stack([np.log1p(future[:h]).sum(axis=0) if panel=='factors' else future[h-1] for h in hs])
                yield panel,path,subset,hs,str(cutoff.date()),{panel:train},truth,target_type


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default='/repo/V11')
    ap.add_argument('--split',choices=['development','holdout'],default='development')
    ap.add_argument('--count',type=int,default=12)
    ap.add_argument('--draws',type=int,default=1000)
    ap.add_argument('--seed',type=int,default=42)
    ap.add_argument('--models',default='v11,reference,v11_safe,fhs60,direct,block5,adaptive')
    ap.add_argument('--out',default='/lab/results/development')
    args=ap.parse_args()
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    rows=[];asset_rows=[];start=time.monotonic()
    code_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/opt/vnext').glob('*.py')}
    sources={k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,(p,_,_) in data_sources(pathlib.Path(args.root)).items()}
    for case_no,case in enumerate(cases(pathlib.Path(args.root),args.split,args.count)):
        panel,path,assets,hs,asof,panels,truth,target_type=case
        steps=np.tile(hs,(len(assets),1))
        hist=prepare(panels,assets,asof,target_type,panel=='macro',absolute=True)
        scale=np.maximum(_scale(hist.steps.to_numpy(float))*np.sqrt(np.array(hs)[:,None]),1e-8)
        for model in args.models.split(','):
            t=time.monotonic()
            if model=='v11':
                if panel=='macro':
                    raw,_=_draw(panels,assets,hs,asof,args.draws,args.seed,target_type=target_type,panel_steps=steps)
                    sample=raw.transpose(0,2,1)
                else:
                    sample,*_=_daily_e2_draws(panels,assets,hs,asof,target_type,args.draws,args.seed)
            elif model=='reference':
                raw,_=_draw(panels,assets,hs,asof,args.draws,args.seed,target_type=target_type,panel_steps=steps if panel=='macro' else None)
                sample=raw.transpose(0,2,1)
            else:
                sample,meta=forecast(panels,assets,steps,asof,target_type,args.draws,args.seed,monthly=panel=='macro',mode=model)
            # Canonical official metric functions, without a fabricated organizer scale.
            flat=sample.transpose(0,2,1).reshape(len(sample),-1)
            result=_composite(flat,truth.T.reshape(-1),weights=(.5,.3,.2),tail_levels=(.01,.05,.95,.99),joint='variogram',tail_metric='pinball',ref_scale=None)
            crps=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
            for ai,asset in enumerate(assets):
                per=_composite(sample[:,:,ai],truth[:,ai],weights=(.5,.3,.2),tail_levels=(.01,.05,.95,.99),joint='variogram',tail_metric='pinball',ref_scale=None)
                asset_rows.append({'case':case_no,'split':args.split,'panel':panel,'asset':asset,'asof':asof,
                                   'model':model,'crps_scaled':float(np.mean(crps[:,ai]/scale[:,ai])),
                                   'marginal':per['marginal'],'joint':per['joint'],'tail':per['tail']})
            low,high=np.quantile(sample,[.05,.95],axis=0)
            rows.append({'case':case_no,'split':args.split,'panel':panel,'assets':'|'.join(assets),'asof':asof,
                         'model':model,'draws':args.draws,'seed':args.seed,'crps_scaled':float(np.mean(crps/scale)),
                         'marginal':result['marginal'],'joint':result['joint'],'tail':result['tail'],
                         'coverage90':float(np.mean((truth>=low)&(truth<=high))),
                         'seconds':time.monotonic()-t})
        pd.DataFrame(rows).to_csv(out/'metrics.csv',index=False)
        pd.DataFrame(asset_rows).to_csv(out/'per_asset_metrics.csv',index=False)
        print(f'{case_no+1:3d} {panel:7s} {asof} done; elapsed={time.monotonic()-start:.1f}s',flush=True)
    metrics=pd.DataFrame(rows)
    summary=metrics.groupby(['panel','model'])[['crps_scaled','marginal','joint','tail','coverage90']].mean().reset_index()
    summary.to_csv(out/'summary.csv',index=False)
    manifest=vars(args)|{'cases':int(metrics['case'].nunique()),'sources':sources,'code_hashes':code_hashes,'seconds':time.monotonic()-start,
                          'label':'numeric pseudo out-of-sample; not official normalized scores',
                          'macro_caveat':'Single published macro vintage; not real-time vintage backtesting. Outcomes may be revised.'}
    (out/'run.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print(summary.to_string(index=False),flush=True)

if __name__=='__main__':main()
