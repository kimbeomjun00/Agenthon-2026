# ## Executive summary (read this first)
# Build the research image and rerun checks against the user's existing public-unit folder.
param(
    [Parameter(Mandatory=$true)][string]$RepositoryPath,
    [ValidateSet('tests','gates','development','holdout42','holdout77','transfer')][string]$Task = 'tests'
)
$ErrorActionPreference = 'Stop'
$bundlePath = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$repoPath = (Resolve-Path -LiteralPath $RepositoryPath).Path
$modelPath = Join-Path $bundlePath 'VNext'
docker build --platform linux/amd64 -t agenthon-vnext:research $modelPath
if ($LASTEXITCODE -ne 0) { throw 'Docker build failed' }
if ($Task -eq 'tests') {
    docker run --rm --network=none --mount "type=bind,source=$modelPath,target=/work,readonly" agenthon-vnext:research python3 -m pytest /work/tests -q -p no:cacheprovider
    exit $LASTEXITCODE
}
$researchPath = $PSScriptRoot
$runName = 'rerun-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
$runOut = '/lab/results/' + $runName
$mounts = @('--mount',"type=bind,source=$repoPath,target=/repo,readonly",'--mount',"type=bind,source=$researchPath,target=/lab")
if ($Task -eq 'gates') {
    $script = @('python3','/lab/validate.py','--units','/repo/V11/units','--out',$runOut)
} elseif ($Task -eq 'transfer') {
    $script = @('python3','/lab/transfer_benchmark.py','--out',$runOut)
} else {
    $split = if ($Task -eq 'development') {'development'} else {'holdout'}
    $seed = if ($Task -eq 'holdout77') {'77'} else {'42'}
    $count = if ($Task -eq 'development') {'10'} else {'16'}
    $script = @('python3','/lab/benchmark.py','--root','/repo/V11','--split',$split,'--count',$count,'--draws','2000','--seed',$seed,'--models','v11,adaptive','--out',$runOut)
}
docker run --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,size=512m --cpus=4 --memory=8g @mounts agenthon-vnext:research @script
exit $LASTEXITCODE
