"""## Executive summary (read this first)
Summarize paired numeric comparisons and year-block bootstrap uncertainty.
The scores are local diagnostic quantities and never official leaderboard scores.
"""
import json
import pathlib
import numpy as np
import pandas as pd

root=pathlib.Path(__file__).resolve().parent
paths=[root/'results'/name for name in ('final42','final77')]
frames=[];af=[]
for path in paths:
    frames.append(pd.read_csv(path/'metrics.csv'))
    af.append(pd.read_csv(path/'per_asset_metrics.csv'))
data=pd.concat(frames,ignore_index=True);assets=pd.concat(af,ignore_index=True)
out=root/'results'/'analysis_final';out.mkdir(parents=True,exist_ok=False)
summary=data.groupby(['panel','model'])[['crps_scaled','marginal','joint','tail','coverage90']].mean().reset_index()
summary.to_csv(out/'summary.csv',index=False)
asset_summary=assets.groupby(['panel','asset','model'])[['crps_scaled','marginal','joint','tail']].mean().reset_index()
asset_summary.to_csv(out/'per_asset_summary.csv',index=False)
paired=data.groupby(['panel','case','asof','model'])['crps_scaled'].mean().unstack('model').reset_index()
paired['year']=paired['asof'].str[:4]
rng=np.random.default_rng(881031)
comparisons=[]
for panel,g in paired.groupby('panel'):
    years=list(g['year'].unique());samples=[]
    for _ in range(5000):
        selected=rng.choice(years,size=len(years),replace=True)
        vals=pd.concat([g[g['year']==y] for y in selected])
        samples.append(100*(1-vals['adaptive'].mean()/vals['v11'].mean()))
    comparison={'panel':panel,'distinct_cases':len(g),'v11':float(g['v11'].mean()),'vnext':float(g['adaptive'].mean()),
                'improvement_percent':float(100*(1-g['adaptive'].mean()/g['v11'].mean())),
                'ci95_percent':np.quantile(samples,[.025,.975]).tolist(),
                'paired_win_fraction':float((g['adaptive']<g['v11']).mean())}
    comparisons.append(comparison)
result={'distinct_cases':int(data['case'].nunique()),'seed_runs':2,'seeds':[42,77],'draws':2000,
        'comparisons':comparisons,'bootstrap':'5000 resamples of calendar-year blocks; only 4-5 blocks, descriptive uncertainty',
        'primary_metric':'Marginal CRPS divided cellwise by cutoff-history EWMA/full SD times sqrt(h). A surrogate, not the contest scale.',
        'official_score':None,'text_accuracy_tested':False}
(out/'analysis.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2));print(asset_summary[asset_summary['panel']=='macro'].to_string(index=False))
