"""## Executive summary (read this first)
Run upstream tests on a temporary LF-normalized copy; preserve the source checkout.
Record genuine failures, including a dictionary-encoded Parquet size-control mismatch.
"""
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

import pyarrow as pa
import pyarrow.parquet as pq
from qfbench2_track_forecasting.limits import inspect_parquet,ParseLimits

out=pathlib.Path('/lab/results/upstream_final')
out.mkdir(parents=True,exist_ok=False)
scratch=pathlib.Path(tempfile.mkdtemp(prefix='agenthon-upstream-'))
snapshot=scratch/'track'
shutil.copytree('/track',snapshot,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
normalized=[]
for file in snapshot.rglob('*.sh'):
    raw=file.read_bytes()
    if b'\r\n' in raw:
        file.write_bytes(raw.replace(b'\r\n',b'\n'));normalized.append(str(file.relative_to(snapshot)))
env=os.environ.copy();env['PYTHONPATH']='/opt:'+str(snapshot)
t=time.monotonic()
run=subprocess.run([sys.executable,'-m','pytest',str(snapshot/'tests'),'-q','-p','no:cacheprovider','--tb=short'],
                   text=True,capture_output=True,env=env,cwd=snapshot)
(out/'pytest.txt').write_text(run.stdout+run.stderr)
# Synthetic diagnostic data only, never a real unit or market value.
path=scratch/'synthetic_size_control.parquet';n=500000
pq.write_table(pa.table({'draw':[0]*n,'asset':['SYN-A']*n,'horizon':[1]*n,'value':[1.]*n}),path,compression='zstd')
facts=inspect_parquet(path,what='synthetic',limits=ParseLimits(max_uncompressed_bytes=1024))
result={'exit_code':run.returncode,'seconds':time.monotonic()-t,'normalized_shell_files':normalized,
        'diagnostic':{'rows':facts.num_rows,'file_bytes':facts.file_bytes,'footer_total_byte_size':facts.uncompressed_bytes,
                      'test_ceiling':1024,'interpretation':'The footer counts encoded page bytes, not decoded constant-column memory.'},
        'source_edited':False,'official_scorer_modified':False}
(out/'result.json').write_text(json.dumps(result,indent=2))
print(run.stdout[-3500:]);print(json.dumps(result,indent=2))
# Preserve the actual pytest exit status; do not declare a failing suite green.
raise SystemExit(run.returncode)
