"""## Executive summary (read this first)
Summarize paired asset and joint losses, with year-block uncertainty rather than seed counts.
Candidate rankings are development evidence; evaluation results never alter runtime routing.
"""
import argparse,json,pathlib
import numpy as np
import pandas as pd

def analyze(root,dest,patterns):
    out=pathlib.Path(dest);out.mkdir(parents=True,exist_ok=True)
    directories=[p for pattern in patterns for p in pathlib.Path(root).glob(pattern) if (p/'asset_metrics.csv').exists()]
    assets=pd.concat([pd.read_csv(p/'asset_metrics.csv') for p in directories],ignore_index=True)
    joint=pd.concat([pd.read_csv(p/'joint_metrics.csv') for p in directories],ignore_index=True)
    assets=assets.groupby(['panel','asset','asof','model']).mean(numeric_only=True).reset_index()
    joint=joint.groupby(['panel','asof','model']).mean(numeric_only=True).reset_index()
    columns=['crps_scaled','marginal','joint','tail','coverage90']
    if 'local_composite' in assets:columns+=['local_composite']
    asset_means=assets.groupby(['panel','asset','model'])[columns].mean().reset_index()
    base=asset_means[asset_means['model']=='v11'].set_index(['panel','asset'])
    for metric in [c for c in columns if c!='coverage90']:
        asset_means['gain_'+metric]=[1-r[metric]/base.loc[(r['panel'],r['asset']),metric] for _,r in asset_means.iterrows()]
    asset_means.to_csv(out/'asset_model_summary.csv',index=False)
    joint_means=joint.groupby(['panel','model'])[['crps_scaled','local_composite','marginal','joint','tail','coverage90']].mean().reset_index()
    b=joint_means[joint_means['model']=='v11'].set_index('panel')
    for metric in ('crps_scaled','local_composite','marginal','joint','tail'):
        joint_means['gain_'+metric]=[1-r[metric]/b.loc[r['panel'],metric] for _,r in joint_means.iterrows()]
    joint_means.to_csv(out/'joint_model_summary.csv',index=False)
    rows=[]
    for (panel,asset),grp in assets.groupby(['panel','asset']):
        pivot=grp.pivot(index='asof',columns='model',values='crps_scaled')
        years=pd.to_datetime(pivot.index).year
        for model in pivot.columns:
            if model=='v11':continue
            blocks=sorted(set(years));rng=np.random.default_rng(612)
            totals=np.array([[pivot.loc[years==year,model].sum(),pivot.loc[years==year,'v11'].sum()] for year in blocks])
            indices=rng.integers(len(blocks),size=(3000,len(blocks)))
            sums=totals[indices].sum(axis=1)
            means=1-sums[:,0]/sums[:,1]
            lo,hi=np.quantile(means,[.025,.975])
            rows.append({'panel':panel,'asset':asset,'model':model,'cases':len(pivot),'year_blocks':len(blocks),
                         'gain':1-pivot[model].mean()/pivot['v11'].mean(),'ci_low':lo,'ci_high':hi,
                         'win_rate':float(np.mean(pivot[model]<pivot['v11']))})
    pd.DataFrame(rows).to_csv(out/'paired_uncertainty.csv',index=False)
    (out/'analysis.json').write_text(json.dumps({'runs':list(map(str,directories)),
        'note':'Seed-averaged case comparisons; 3000 resamples of calendar-year blocks; few blocks, exploratory.',
        'cases_per_panel':assets.groupby('panel')['asof'].nunique().to_dict()},indent=2))
    print(asset_means[asset_means['model']=='specialists'][['panel','asset','gain_crps_scaled','gain_tail']].to_string(index=False))
    print(joint_means[joint_means['model']=='specialists'][['panel','gain_crps_scaled','gain_local_composite']].to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='/lab/results');p.add_argument('--out',required=True)
    p.add_argument('--patterns',default='eval_*');a=p.parse_args();analyze(a.root,a.out,a.patterns.split(','))
