"""## Executive summary (read this first)
Check the built forecast command in four read-only/offline containers, one per family.
Save gate diagnostics, not accuracy scores or answer tables.
"""
import json,pathlib,subprocess,time,tomllib
base=pathlib.Path(__file__).resolve().parent.parent
units=base/'agenthon-v11-work'/'V11'/'units';out=base/'asset-lab'/'results'/'container_final'
out.mkdir(parents=True,exist_ok=False)
cases=['t2-F1-ai-mom-2024','t2-F2-cnh-stress-2015','t2-F3-bear-flattener-2022','t2-F4-cpi-vintage-2022']
code='''import json,pathlib
from qfbench2_track_forecasting.scoring import GATES,hydrate_ctx
ctx={"unit_dir":pathlib.Path("/input"),"output_dir":pathlib.Path("/output"),"realized":None}
hydrate_ctx(ctx)
g={name:gate(ctx).passed for name,gate in GATES}
print(json.dumps(g));raise SystemExit(0 if all(g.values()) else 1)
'''
rows=[]
for name in cases:
    unit=units/name;card=tomllib.loads((unit/'card.toml').read_text(encoding='utf8'))
    dest=out/'outputs'/name;dest.mkdir(parents=True)
    command=['docker','run','--rm','--network=none','--read-only','--tmpfs','/tmp:rw,noexec,nosuid,size=512m',
        '--cpus=4','--memory=4g','--mount',f'type=bind,source={unit},target=/input,readonly',
        '--mount',f'type=bind,source={dest},target=/output','agenthon-vspecial:research']
    t=time.monotonic()
    run=subprocess.run(command+['forecast','--panels','/input/panels','--text','/input/text',
        '--asof',str(card['provenance']['data_cutoff']),'--out','/output/forecast.parquet'],capture_output=True,text=True)
    gate=subprocess.run(command+['python3','-c',code],capture_output=True,text=True) if run.returncode==0 else None
    row={'unit':name,'forecast_exit':run.returncode,'gate_exit':gate.returncode if gate else None,
         'gates':json.loads(gate.stdout) if gate and gate.returncode==0 else {},
         'files':sorted(p.name for p in dest.iterdir()),'seconds':time.monotonic()-t,
         'stdout':run.stdout,'stderr':run.stderr}
    rows.append(row);(out/'result.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    print(name,row['forecast_exit'],row['gate_exit'],flush=True)
    if not gate or run.returncode or gate.returncode:raise SystemExit(1)
