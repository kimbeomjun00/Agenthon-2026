## Executive summary (read this first)

Freeze the numerical candidate set and conservative menu before 2020-2024 evaluation.
This is an exploratory pseudo backtest, not the private leaderboard or a fresh unseen dataset.

- All 28 available series: 6 UST, 10 G10, 6 factors, 6 monthly macro.
- GDP has no supplied contiguous history; no GDP accuracy claim is possible.
- Development: 36 non-overlapping 63-business-day origins per daily panel, 18 nine-month origins for macro, 2006-2019; 1,000 draws, seed 42.
- Daily horizons [5,21,63], monthly steps [1,3,9]. Actual submission horizon keys still come unchanged from each card.
- Subsequent evaluation: every non-overlapping eligible origin in 2020-2024; 2,000 draws, seeds 42 and 77, averaging seeds on each event before analysis.
- 2020-2024 was previously explored in the VNext study, so it is NOT a pristine holdout.
- A second monthly grid is a horizon-sensitivity check, NOT additional independent events.
- Tests compare uploaded reconstructed V11, prior VNext, all-specialist router, conservative router. Candidate rankings remain development-only.
- Runtime selector: up to 8 fully resolved local folds; 256 draws; 85% marginal CRPS + 15% 5/95% pinball, cutoff-history SD scaling. Require >=3% improvement and >=50% fold wins. Mix 25% common-shock baseline draws. These are selector design choices, not official score normalization.
- Conservative menu, fixed from development: CPI/PCE and NFP allow trend models except mean_revert; HML allows zero/shrunken/momentum mean; BAB allows shrunken mean; SMB allows zero/shrunken mean. Other tested assets retain V11. Unknown monthly assets retain baseline.
- All candidates are also retained in source for review; menus contain no fitted coefficients or target tables. All numerical parameters fit from the current unit's as-of-valid inputs.
- Canonical official marginal, joint variogram, tail pinball calculations are imported unchanged. Local composite uses a 24-outcome Monte Carlo baseline expectation from public inputs, NOT organizer M0 scales. Per-asset primary metric is cutoff-SD-scaled marginal CRPS, with raw losses also reported.
- Numeric experiments disable House. Real House/text uplift is untested.
- One revised macro vintage is used. Monthly analysis is not a real-time release-vintage backtest.
- Final evaluation does not tune the router. A failure is reported and the candidate remains research-only.
