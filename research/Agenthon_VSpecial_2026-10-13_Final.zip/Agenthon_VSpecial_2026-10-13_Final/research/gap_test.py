"""## Executive summary (read this first)
Stress-test the stale-history module on 10 G10 currencies with invented five-year gaps.
This supplies robustness evidence only, not the missing EM-card outcomes.
"""
import argparse,hashlib,json,pathlib,time
import numpy as np
import pandas as pd
from qfbench2_common.scoring.crps import crps_ensemble
from vnext.specialists import forecast,prepare,_scale
from vnext.transfer import adjust
from v11_new.production_cli import _daily_e2_draws
from experiment import sources

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--seed',type=int,default=42)
    args=ap.parse_args();out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    source,df,acol=sources(pathlib.Path('/repo/V11'))['fx'];dates=pd.DatetimeIndex(sorted(df['date'].unique()))
    indices=np.flatnonzero((dates.year>=2020)&(np.arange(len(dates))+63<len(dates)))
    origins=indices[np.unique(np.linspace(0,len(indices)-1,6).round().astype(int))]
    rows=[];t=time.monotonic()
    for assets in [['EUR','JPY','GBP'],['AUD','CAD','NZD'],['CHF','SEK'],['NOK','DKK']]:
        wide=df[df[acol].isin(assets)].pivot(index='date',columns=acol,values='value').reindex(columns=assets)
        for ix in origins:
            cutoff=dates[ix];asof=str(cutoff.date());train=df[df['date']<=cutoff]
            keep=~train[acol].isin(assets)|(train['date']<=cutoff-pd.DateOffset(years=5))|(train['date']==cutoff)
            panels={'fx':train[keep]};steps=np.tile([21,63],(len(assets),1))
            truth=np.stack([wide.loc[dates[ix+h]].to_numpy(float) for h in [21,63]])
            state=prepare(panels,assets,asof,'level');scale=np.maximum(_scale(state.x)*np.sqrt(np.array([21,63])[:,None]),1e-8)
            safe,_=forecast(panels,assets,steps,asof,'level',2000,args.seed,policy='conservative')
            transferred,meta=adjust(panels,assets,steps,asof,safe,args.seed)
            original,*_=_daily_e2_draws(panels,assets,[21,63],asof,'level',2000,args.seed)
            for name,sample in [('v11',original),('gap_safe',safe),('proxy',transferred)]:
                loss=crps_ensemble(sample.reshape(len(sample),-1),truth.reshape(-1)).reshape(truth.shape)
                for ai,a in enumerate(assets):
                    rows.append({'asof':asof,'asset':a,'model':name,'seed':args.seed,'crps_scaled':float(np.mean(loss[:,ai]/scale[:,ai])),
                                 'proxy_applied':meta.get('applied',False)})
            print(assets,asof,flush=True)
    data=pd.DataFrame(rows);data.to_csv(out/'metrics.csv',index=False)
    data.groupby(['asset','model']).mean(numeric_only=True).reset_index().to_csv(out/'summary.csv',index=False)
    (out/'run.json').write_text(json.dumps({'cases':24,'draws':2000,'seed':args.seed,'seconds':time.monotonic()-t,
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'label':'synthetic G10 gaps; not actual EM accuracy'},indent=2))
    print(data.groupby('model')['crps_scaled'].mean().to_string())

if __name__=='__main__':main()
