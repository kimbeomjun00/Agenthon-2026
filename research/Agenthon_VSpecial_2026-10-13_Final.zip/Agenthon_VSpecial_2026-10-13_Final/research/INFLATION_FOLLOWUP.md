## Executive summary (read this first)

Phase 2 explores uncertain inflation trends after Phase 1 exposed undercoverage.
These are further exploratory tests, with no claim of an untouched final holdout.

Phase 1 was numerically frozen before its evaluation. Its NFP improvement did not reproduce;
factor improvements shrank markedly. The conservative recommended integration therefore keeps
non-price series on V11 rather than adopting every development winner.

Phase 2 adds 8 price trend specifications × 4 drift-uncertainty strengths (0, 0.5, 1, 1.5),
plus a baseline. A common historical vector of changes in rolling trends couples every price
series. Runtime choices use at most 8 resolved local folds and never the later task outcome.
Fifteen percent of entire draws use the baseline for model uncertainty.

Run the Phase 2 candidate grid on 2006-2019 first, then two seeds on 2020-2024, then a separate
monthly [1,3,6] horizon-sensitivity grid. Those grids can overlap each other; they are not
independent event counts. No NFP or daily-market parameters are tuned to the Phase 1 results.
Price-only integration is a post-comparison support decision, not a fresh held-out model claim.
