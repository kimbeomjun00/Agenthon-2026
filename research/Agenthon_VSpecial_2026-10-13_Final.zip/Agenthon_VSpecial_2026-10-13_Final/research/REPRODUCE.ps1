# ## Executive summary (read this first)
# Rebuild the research image and reproduce comparisons from the user's public V11 checkout.
param([Parameter(Mandatory=$true)][string]$RepositoryRoot)
$ErrorActionPreference = 'Stop'
$bundleRoot = Split-Path -Parent $PSScriptRoot
$modelRoot = Join-Path $bundleRoot 'VSpecial'
$repoResolved = (Resolve-Path -LiteralPath $RepositoryRoot).Path
$researchResolved = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if (!(Test-Path -LiteralPath (Join-Path $repoResolved 'V11/units'))) { throw 'RepositoryRoot must contain V11/units' }
docker build -t agenthon-vspecial:research $modelRoot
if ($LASTEXITCODE -ne 0) { throw 'Docker build failed' }
foreach ($panel in @('rates','fx','factors','macro')) {
    foreach ($seed in @(42,77)) {
        docker run --rm --network none --cpus=4 --memory=4g -e OPENBLAS_NUM_THREADS=1 `
          --mount "type=bind,source=$repoResolved,target=/repo,readonly" `
          --mount "type=bind,source=$researchResolved,target=/lab" `
          agenthon-vspecial:research python /lab/experiment.py --panel $panel --split evaluation `
          --draws 2000 --seed $seed --router --previous --out "/lab/results/repro$seed-$panel"
        if ($LASTEXITCODE -ne 0) { throw "Experiment failed: $panel seed $seed" }
    }
}
foreach ($seed in @(42,77)) {
    docker run --rm --network none --cpus=4 --memory=4g -e OPENBLAS_NUM_THREADS=1 `
      --mount "type=bind,source=$repoResolved,target=/repo,readonly" `
      --mount "type=bind,source=$researchResolved,target=/lab" `
      agenthon-vspecial:research python /lab/experiment.py --panel macro --split evaluation `
      --draws 2000 --seed $seed --inflation --previous --out "/lab/results/repro-price$seed"
    if ($LASTEXITCODE -ne 0) { throw "Price experiment failed: seed $seed" }
}
# Existing result directories are never overwritten. Rename a completed repro directory to rerun.
